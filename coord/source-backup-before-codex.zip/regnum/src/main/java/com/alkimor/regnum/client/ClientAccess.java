package com.alkimor.regnum.client;

import com.alkimor.regnum.client.screen.CityScreen;
import com.alkimor.regnum.client.screen.CommandScreen;
import com.alkimor.regnum.client.screen.JournalScreen;
import com.alkimor.regnum.core.network.ArmyInfoPayload;
import com.alkimor.regnum.core.network.CityInfoPayload;
import com.alkimor.regnum.core.network.SkillSyncPayload;
import com.alkimor.regnum.survival.Skills;
import net.minecraft.client.Minecraft;

/** Обработка пакетов на клиенте. Загружается только на клиенте. */
public final class ClientAccess {
    private ClientAccess() {}

    public static void onSkillSync(SkillSyncPayload p) {
        Skills.clientXp = p.xp();
        Skills.clientHonor = p.honor();
        if (p.openJournal()) Minecraft.getInstance().setScreen(new JournalScreen());
    }

    public static void onCityInfo(CityInfoPayload p) {
        Minecraft.getInstance().setScreen(new CityScreen(p));
    }

    public static void onArmyInfo(ArmyInfoPayload p) {
        Minecraft.getInstance().setScreen(new CommandScreen(p));
    }
}
