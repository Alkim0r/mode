package com.alkimor.regnum.client;

import com.alkimor.regnum.Regnum;
import com.alkimor.regnum.client.render.CryptLordRenderer;
import com.alkimor.regnum.client.render.NpcRenderer;
import com.alkimor.regnum.dungeon.DungeonModule;
import com.alkimor.regnum.kingdom.BanditEntity;
import com.alkimor.regnum.kingdom.KingdomModule;
import com.alkimor.regnum.kingdom.SoldierEntity;
import com.alkimor.regnum.wanderers.WandererEntity;
import com.alkimor.regnum.wanderers.WanderersModule;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Регистрация клиентских рендеров. */
@EventBusSubscriber(modid = Regnum.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    private static final String[] SOLDIER_SKINS = {"steve", "alex", "kai", "makena", "noor", "sunny", "zuri", "ari", "efe"};
    private static final String[] BANDIT_SKINS = {"efe", "kai", "zuri", "steve"};
    private static final String[] WANDERER_SKINS = {"ari", "sunny", "noor", "makena", "alex"};

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(KingdomModule.SOLDIER.get(),
                ctx -> new NpcRenderer<SoldierEntity>(ctx, SoldierEntity::getSkinIndex, SOLDIER_SKINS));
        event.registerEntityRenderer(KingdomModule.BANDIT.get(),
                ctx -> new NpcRenderer<BanditEntity>(ctx, BanditEntity::getSkinIndex, BANDIT_SKINS));
        event.registerEntityRenderer(WanderersModule.WANDERER.get(),
                ctx -> new NpcRenderer<WandererEntity>(ctx, WandererEntity::getSkinIndex, WANDERER_SKINS));
        event.registerEntityRenderer(DungeonModule.CRYPT_LORD.get(), CryptLordRenderer::new);
    }
}
