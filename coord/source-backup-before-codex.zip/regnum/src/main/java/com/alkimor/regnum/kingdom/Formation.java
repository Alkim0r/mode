package com.alkimor.regnum.kingdom;

import net.minecraft.world.phys.Vec3;

/** Построения отряда. Смещения считаются в локальных координатах (вправо, назад) от точки сбора. */
public enum Formation {
    LINE("Линия"),
    WEDGE("Клин"),
    SQUARE("Каре"),
    LOOSE("Рассыпной строй");

    public final String title;

    Formation(String title) {
        this.title = title;
    }

    public static Formation byId(int id) {
        Formation[] v = values();
        return id >= 0 && id < v.length ? v[id] : LINE;
    }

    /** @return x = вправо, z = назад */
    public Vec3 localOffset(int slot, int size) {
        size = Math.max(1, size);
        switch (this) {
            case LINE -> {
                int w = Math.min(size, 8);
                int row = slot / w, col = slot % w;
                return new Vec3((col - (w - 1) / 2.0) * 1.6, 0, row * 1.8);
            }
            case WEDGE -> {
                if (slot == 0) return Vec3.ZERO;
                int k = (slot + 1) / 2;
                double side = (slot % 2 == 1) ? -1 : 1;
                return new Vec3(side * k * 1.4, 0, k * 1.4);
            }
            case SQUARE -> {
                double r = Math.max(2.0, size * 0.45);
                double a = 2 * Math.PI * slot / size;
                return new Vec3(Math.cos(a) * r, 0, Math.sin(a) * r);
            }
            default -> {
                int w = (int) Math.ceil(Math.sqrt(size));
                int row = slot / w, col = slot % w;
                return new Vec3((col - (w - 1) / 2.0) * 3.0, 0, row * 3.0);
            }
        }
    }

    /** Мировая позиция бойца: anchor + поворот на yaw (градусы Minecraft). */
    public Vec3 worldPos(Vec3 anchor, float yaw, int slot, int size, double extraBack) {
        Vec3 o = localOffset(slot, size);
        double rad = Math.toRadians(yaw);
        double fx = -Math.sin(rad), fz = Math.cos(rad);      // вперёд
        double rx = -Math.cos(rad), rz = -Math.sin(rad);     // вправо
        double back = o.z + extraBack;
        return new Vec3(anchor.x + rx * o.x - fx * back, anchor.y, anchor.z + rz * o.x - fz * back);
    }
}
