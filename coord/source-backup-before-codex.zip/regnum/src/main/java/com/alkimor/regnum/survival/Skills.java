package com.alkimor.regnum.survival;

import com.alkimor.regnum.Regnum;
import com.alkimor.regnum.core.RegnumConfig;
import com.alkimor.regnum.core.Text;
import com.alkimor.regnum.core.network.SkillSyncPayload;
import net.minecraft.ChatFormatting;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.PacketDistributor;

/** Точка входа для всех модулей: опыт навыков, уровни, честь. */
public final class Skills {
    private Skills() {}

    private static final ResourceLocation FITNESS_HEALTH = Regnum.id("fitness_health");

    /** Копия опыта локального игрока на клиенте (заполняется пакетом {@link SkillSyncPayload}). */
    public static int[] clientXp = new int[Skill.values().length];
    public static int clientHonor = 0;

    public static SurvivorData data(Player p) {
        return p.getData(SurvivalModule.SURVIVOR);
    }

    public static int level(Player p, Skill s) {
        if (p.level().isClientSide) {
            return Skill.levelFor(clientXp.length > s.ordinal() ? clientXp[s.ordinal()] : 0);
        }
        return data(p).level(s);
    }

    public static void addXp(Player p, Skill s, int base) {
        if (!(p instanceof ServerPlayer sp) || !RegnumConfig.SURVIVAL_ENABLED.get() || base <= 0) return;
        if (sp.isCreative() || sp.isSpectator()) return;
        int amount = Math.max(1, (int) Math.round(base * RegnumConfig.SKILL_XP_MULTIPLIER.get()));
        SurvivorData d = data(sp);
        int before = d.level(s);
        d.addXp(s, amount);
        int after = d.level(s);
        if (after > before) {
            sp.sendSystemMessage(Text.of("✦ Навык «" + s.title + "» повышен до " + after + " уровня! ", s.color, ChatFormatting.BOLD)
                    .append(Text.of(s.bonus, ChatFormatting.GRAY)));
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6f, 1.3f);
            if (s == Skill.FITNESS) applyFitness(sp);
            sync(sp, false);
        } else if (amount >= 4) {
            Text.bar(sp, "+" + amount + " " + s.title, s.color);
        }
    }

    public static void addHonor(ServerPlayer sp, int delta, String reason) {
        SurvivorData d = data(sp);
        String before = SurvivorData.honorTitle(d.honor());
        d.addHonor(delta);
        String after = SurvivorData.honorTitle(d.honor());
        Text.bar(sp, (delta >= 0 ? "Честь +" : "Честь ") + delta + " — " + reason, delta >= 0 ? ChatFormatting.YELLOW : ChatFormatting.DARK_RED);
        if (!before.equals(after)) {
            Text.gold(sp, "Молва о вас изменилась. Теперь вас знают как: «" + after + "»");
        }
    }

    public static void sync(ServerPlayer sp, boolean openJournal) {
        SurvivorData d = data(sp);
        int[] xp = new int[Skill.values().length];
        for (Skill s : Skill.values()) xp[s.ordinal()] = d.xp(s);
        PacketDistributor.sendToPlayer(sp, new SkillSyncPayload(xp, d.honor(), openJournal));
    }

    /** Бонус к здоровью от Выносливости: +2 ед. (1 сердце) за каждые 3 уровня. */
    public static void applyFitness(ServerPlayer sp) {
        AttributeInstance inst = sp.getAttribute(Attributes.MAX_HEALTH);
        if (inst == null) return;
        inst.removeModifier(FITNESS_HEALTH);
        int bonus = (data(sp).level(Skill.FITNESS) / 3) * 2;
        if (bonus > 0) {
            inst.addTransientModifier(new AttributeModifier(FITNESS_HEALTH, bonus, AttributeModifier.Operation.ADD_VALUE));
        }
        if (sp.getHealth() > sp.getMaxHealth()) sp.setHealth(sp.getMaxHealth());
    }

    /** Множитель силы лечения от Медицины. */
    public static float medicineFactor(Player p) {
        return 1.0f + 0.1f * level(p, Skill.MEDICINE);
    }
}
