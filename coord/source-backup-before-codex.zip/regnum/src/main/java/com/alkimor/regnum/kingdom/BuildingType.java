package com.alkimor.regnum.kingdom;

/** Постройки города. Каждая ставится блоком внутри территории своего города. */
public enum BuildingType {
    BARRACKS("Казарма", "Позволяет нанимать войска, +5 к лимиту армии"),
    MARKET("Рынок", "+3 изумруда в казну ежедневно"),
    WATCHTOWER("Сторожевая башня", "Раннее предупреждение о набегах, подсветка врагов");

    public final String title;
    public final String effect;

    BuildingType(String title, String effect) {
        this.title = title;
        this.effect = effect;
    }
}
