package com.alkimor.regnum.kingdom;

/** Типы войск. Ополченцы вербуются из жителей деревень, остальные — в казарме. */
public enum SoldierType {
    MILITIA("Ополченец", 0, 0, 20, 1),
    SWORDSMAN("Мечник", 8, 1, 30, 1),
    ARCHER("Лучник", 10, 1, 22, 1),
    KNIGHT("Рыцарь", 24, 2, 50, 2);

    public final String title;
    /** Стоимость найма в изумрудах из казны. */
    public final int cost;
    /** Жалованье в день. */
    public final int upkeep;
    public final double health;
    /** Минимальный уровень города для найма. */
    public final int minCityLevel;

    SoldierType(String title, int cost, int upkeep, double health, int minCityLevel) {
        this.title = title;
        this.cost = cost;
        this.upkeep = upkeep;
        this.health = health;
        this.minCityLevel = minCityLevel;
    }

    public static SoldierType byId(int id) {
        SoldierType[] v = values();
        return id >= 0 && id < v.length ? v[id] : SWORDSMAN;
    }
}
