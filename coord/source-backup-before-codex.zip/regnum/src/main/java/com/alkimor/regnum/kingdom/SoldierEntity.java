package com.alkimor.regnum.kingdom;

import com.alkimor.regnum.core.Text;
import com.alkimor.regnum.kingdom.ai.SoldierAssistKingGoal;
import com.alkimor.regnum.kingdom.ai.SoldierMoveGoal;
import com.alkimor.regnum.kingdom.ai.SoldierRangedGoal;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Солдат королевства. Подчиняется владельцу-королю, состоит в одном из 4 отрядов,
 * выполняет приказы и держит строй.
 */
public class SoldierEntity extends PathfinderMob implements RangedAttackMob {
    private static final EntityDataAccessor<Integer> DATA_TYPE = SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SKIN = SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);

    @Nullable private UUID owner;
    @Nullable private UUID cityId;
    @Nullable private UUID attackTargetId;
    private int squad = 1;
    private Order order = Order.FOLLOW;
    private Formation formation = Formation.LINE;
    private int slot = 0;
    private int squadSize = 1;
    private float facing = 0f;
    private Vec3 post = Vec3.ZERO;

    public SoldierEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        setCanPickUpLoot(false);
        ((net.minecraft.world.entity.ai.navigation.GroundPathNavigation) getNavigation()).setCanOpenDoors(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.MOVEMENT_SPEED, 0.32)
                .add(Attributes.ATTACK_DAMAGE, 2.0)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.ARMOR, 2.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_TYPE, SoldierType.SWORDSMAN.ordinal());
        builder.define(DATA_SKIN, 0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new OpenDoorGoal(this, true));
        goalSelector.addGoal(2, new SoldierRangedGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, true) {
            @Override
            public boolean canUse() {
                return !isArcher() && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return !isArcher() && super.canContinueToUse();
            }
        });
        goalSelector.addGoal(4, new SoldierMoveGoal(this));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8f));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));

        targetSelector.addGoal(1, new HurtByTargetGoal(this, SoldierEntity.class, Player.class));
        targetSelector.addGoal(2, new SoldierAssistKingGoal(this));
        targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Mob.class, 5, true, false,
                e -> e instanceof Enemy && !(e instanceof Creeper) && withinEngagement(e)));
    }

    // ------------------------------------------------------------------ настройка

    public void setup(SoldierType type, UUID owner, @Nullable UUID cityId, int squad) {
        this.owner = owner;
        this.cityId = cityId;
        this.squad = Math.max(1, Math.min(4, squad));
        entityData.set(DATA_TYPE, type.ordinal());
        entityData.set(DATA_SKIN, random.nextInt(1000));
        AttributeInstance hp = getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) hp.setBaseValue(type.health);
        setHealth(getMaxHealth());
        equip(type);
        updateName();
    }

    private void equip(SoldierType type) {
        switch (type) {
            case MILITIA -> {
                setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.STONE_SWORD));
                setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.LEATHER_CHESTPLATE));
            }
            case SWORDSMAN -> {
                setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
                setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
                setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.CHAINMAIL_CHESTPLATE));
                setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.LEATHER_LEGGINGS));
            }
            case ARCHER -> {
                setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
                setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.CHAINMAIL_HELMET));
                setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.LEATHER_CHESTPLATE));
            }
            case KNIGHT -> {
                setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
                setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
                setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
                setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
                setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.IRON_LEGGINGS));
                setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.IRON_BOOTS));
            }
        }
        for (EquipmentSlot s : EquipmentSlot.values()) setDropChance(s, 0f);
    }

    private void updateName() {
        setCustomName(Component.literal(getSoldierType().title + " · Отряд " + squad));
        setCustomNameVisible(false);
    }

    // ------------------------------------------------------------------ доступ

    public SoldierType getSoldierType() {
        return SoldierType.byId(entityData.get(DATA_TYPE));
    }

    public int getSkinIndex() {
        return entityData.get(DATA_SKIN);
    }

    public boolean isArcher() {
        return getSoldierType() == SoldierType.ARCHER;
    }

    @Nullable
    public UUID getOwnerId() {
        return owner;
    }

    @Nullable
    public UUID getCityId() {
        return cityId;
    }

    public void clearCity() {
        cityId = null;
    }

    public boolean isOwnedBy(Entity e) {
        return owner != null && e != null && owner.equals(e.getUUID());
    }

    @Nullable
    public Player getOwnerPlayer() {
        return owner == null ? null : level().getPlayerByUUID(owner);
    }

    public int getSquad() {
        return squad;
    }

    public void setSquad(int squad) {
        this.squad = squad;
        updateName();
    }

    public Order getOrder() {
        return order;
    }

    public Formation getFormation() {
        return formation;
    }

    public float getFacing() {
        return facing;
    }

    // ------------------------------------------------------------------ приказы

    public void command(Order order, Vec3 post, float facing, Formation formation, int slot, int size, @Nullable UUID target) {
        this.order = order;
        this.post = post;
        this.facing = facing;
        this.formation = formation;
        this.slot = slot;
        this.squadSize = size;
        this.attackTargetId = target;
        if (order != Order.ATTACK_TARGET && getTarget() != null && !withinEngagement(getTarget())) setTarget(null);
        getNavigation().stop();
    }

    /** Точка, где боец должен стоять по текущему приказу. */
    public Vec3 desiredPosition() {
        if (order == Order.FOLLOW) {
            Player king = getOwnerPlayer();
            if (king != null) return formation.worldPos(king.position(), king.getYRot(), slot, squadSize, 3.0);
            return position();
        }
        if (order == Order.ATTACK_TARGET) return position();
        return post;
    }

    public boolean withinEngagement(LivingEntity e) {
        if (isAlliedTo(e)) return false;
        Vec3 center = order == Order.FOLLOW && getOwnerPlayer() != null ? getOwnerPlayer().position() : desiredPosition();
        double r = order.engageRadius;
        return e.position().distanceToSqr(center) <= r * r;
    }

    @Override
    public boolean isAlliedTo(Entity other) {
        if (other instanceof SoldierEntity s && owner != null && owner.equals(s.owner)) return true;
        if (owner != null && other.getUUID().equals(owner)) return true;
        return super.isAlliedTo(other);
    }

    // ------------------------------------------------------------------ тик

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;

        if (order == Order.ATTACK_TARGET && tickCount % 10 == 0) {
            Entity t = attackTargetId != null && level() instanceof ServerLevel sl ? sl.getEntity(attackTargetId) : null;
            if (t instanceof LivingEntity le && le.isAlive()) {
                setTarget(le);
            } else {
                // цель повержена — занять позицию там, где стоим
                command(Order.HOLD, position(), getYRot(), formation, slot, squadSize, null);
            }
        }

        LivingEntity target = getTarget();
        if (target != null && order != Order.ATTACK_TARGET) {
            double r = order.engageRadius * 1.5;
            if (target.position().distanceToSqr(desiredPosition()) > r * r || isAlliedTo(target)) setTarget(null);
        }

        if (tickCount % 60 == 0 && getTarget() == null && getHealth() < getMaxHealth()) heal(1.0f);

        // Проверка верности: солдат, которого вычеркнули из списков города (не заплатили жалованье), дезертирует.
        if (cityId != null && tickCount % 200 == 0 && level() instanceof ServerLevel sl) {
            City c = KingdomData.get(sl.getServer()).byId(cityId);
            if (c == null) {
                cityId = null;
            } else if (!c.soldiers.containsKey(getUUID())) {
                if (getOwnerPlayer() instanceof ServerPlayer king) {
                    Text.bad(king, getSoldierType().title + " из отряда " + squad + " дезертировал: казна не платит жалованье.");
                }
                discard();
                return;
            }
        }

        if (order == Order.FOLLOW && tickCount % 20 == 0) {
            Player king = getOwnerPlayer();
            if (king != null && king.level() == level() && distanceToSqr(king) > 40 * 40) tryTeleportNear(king);
        }
    }

    private void tryTeleportNear(Player king) {
        BlockPos base = king.blockPosition();
        for (int i = 0; i < 10; i++) {
            BlockPos p = base.offset(random.nextInt(7) - 3, random.nextInt(3) - 1, random.nextInt(7) - 3);
            if (level().getBlockState(p.below()).isSolid() && level().noCollision(this, getBoundingBox().move(Vec3.atBottomCenterOf(p).subtract(position())))) {
                moveTo(p.getX() + 0.5, p.getY(), p.getZ() + 0.5, getYRot(), getXRot());
                getNavigation().stop();
                return;
            }
        }
    }

    // ------------------------------------------------------------------ дальний бой

    @Override
    public void performRangedAttack(LivingEntity target, float velocity) {
        ItemStack bow = getMainHandItem();
        Arrow arrow = new Arrow(level(), this, new ItemStack(Items.ARROW), bow.is(Items.BOW) ? bow : null);
        arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
        double dx = target.getX() - getX();
        double dy = target.getY(0.3333) - arrow.getY();
        double dz = target.getZ() - getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        arrow.shoot(dx, dy + dist * 0.2, dz, 1.6f, 4f);
        playSound(SoundEvents.ARROW_SHOOT, 1.0f, 1.0f / (getRandom().nextFloat() * 0.4f + 0.8f));
        level().addFreshEntity(arrow);
    }

    // ------------------------------------------------------------------ взаимодействие

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (player.getItemInHand(hand).getItem() instanceof CommanderBatonItem) return InteractionResult.PASS;
        if (!isOwnedBy(player)) return InteractionResult.PASS;
        if (!level().isClientSide) {
            player.sendSystemMessage(Text.of(getSoldierType().title + " (отряд " + squad + ")", ChatFormatting.GOLD)
                    .append(Text.of(" — здоровье " + Math.round(getHealth()) + "/" + Math.round(getMaxHealth())
                            + ", приказ: " + order.title + ", строй: " + formation.title, ChatFormatting.GRAY)));
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level() instanceof ServerLevel sl) {
            KingdomData.get(sl.getServer()).onSoldierLost(cityId, getUUID());
            if (getOwnerPlayer() instanceof ServerPlayer king) {
                Text.bad(king, "Ваш " + getSoldierType().title.toLowerCase() + " из отряда " + squad + " пал в бою.");
            }
        }
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    // ------------------------------------------------------------------ сохранение

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (owner != null) tag.putUUID("Owner", owner);
        if (cityId != null) tag.putUUID("City", cityId);
        if (attackTargetId != null) tag.putUUID("AttackTarget", attackTargetId);
        tag.putInt("SoldierType", entityData.get(DATA_TYPE));
        tag.putInt("Skin", entityData.get(DATA_SKIN));
        tag.putInt("Squad", squad);
        tag.putInt("Order", order.ordinal());
        tag.putInt("Formation", formation.ordinal());
        tag.putInt("Slot", slot);
        tag.putInt("SquadSize", squadSize);
        tag.putFloat("Facing", facing);
        tag.putDouble("PostX", post.x);
        tag.putDouble("PostY", post.y);
        tag.putDouble("PostZ", post.z);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        cityId = tag.hasUUID("City") ? tag.getUUID("City") : null;
        attackTargetId = tag.hasUUID("AttackTarget") ? tag.getUUID("AttackTarget") : null;
        entityData.set(DATA_TYPE, tag.getInt("SoldierType"));
        entityData.set(DATA_SKIN, tag.getInt("Skin"));
        squad = Math.max(1, tag.getInt("Squad"));
        order = Order.byId(tag.getInt("Order"));
        formation = Formation.byId(tag.getInt("Formation"));
        slot = tag.getInt("Slot");
        squadSize = Math.max(1, tag.getInt("SquadSize"));
        facing = tag.getFloat("Facing");
        post = new Vec3(tag.getDouble("PostX"), tag.getDouble("PostY"), tag.getDouble("PostZ"));
    }
}
