package com.alkimor.regnum.client;

import com.alkimor.regnum.Regnum;
import com.alkimor.regnum.client.screen.CityScreen;
import com.alkimor.regnum.client.screen.CommandScreen;
import com.alkimor.regnum.client.screen.JournalScreen;
import com.alkimor.regnum.client.screen.TradeScreen;
import com.alkimor.regnum.core.ModRegistries;
import com.alkimor.regnum.core.network.ArmyInfoPayload;
import com.alkimor.regnum.core.network.CityInfoPayload;
import com.alkimor.regnum.core.network.TradeInfoPayload;
import com.alkimor.regnum.dungeon.DungeonModule;
import com.alkimor.regnum.dungeon.RegionsModule;
import com.alkimor.regnum.kingdom.BanditEntity;
import com.alkimor.regnum.kingdom.KingdomModule;
import com.alkimor.regnum.kingdom.SoldierEntity;
import com.alkimor.regnum.kingdom.SoldierType;
import com.alkimor.regnum.wanderers.Persona;
import com.alkimor.regnum.wanderers.WandererEntity;
import com.alkimor.regnum.wanderers.WanderersModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Визуальный автотест (-Dregnum.visualtest=true, задача runVisualTest):
 * загружает мир, расставляет мобов, боссов, блоки, облетает данжи и делает скриншоты в run-visual/screenshots.
 */
@EventBusSubscriber(modid = Regnum.MODID, value = Dist.CLIENT)
public final class ClientVisualTest {
    private ClientVisualTest() {}

    private record Step(String name, Consumer<MinecraftServer> server, Runnable client, int delay, boolean gui) {}

    private static final List<Step> STEPS = new ArrayList<>();
    private static final List<Entity> scene = new ArrayList<>();
    private static ServerLevel sceneLevel;
    private static int index = -1, timer = 0, readyTicks = 0;
    private static boolean shotPending = false;
    private static volatile boolean serverReady = true;
    private static volatile Throwable serverFailure;
    private static Runnable pendingClient;
    private static boolean originalMineLite;

    private static final int Y = 200;
    private static BlockPos DT_AT;

    private static boolean enabled() {
        return Boolean.getBoolean("regnum.visualtest");
    }

    private static void log(String s) {
        Regnum.LOGGER.info("[REGNUM-VISUAL] {}", s);
    }

    // ================================================================== сценарий

    private static void build() {
        STEPS.add(new Step(null, ClientVisualTest::setupWorld, null, 60, false));

        for (int culture = 0; culture < 6; culture++) {
            final int selectedCulture = culture;
            for (int group = 0; group < (SoldierType.values().length + 3) / 4; group++) {
                final int first = group * 4;
                STEPS.add(new Step("01_army_" + com.alkimor.regnum.kingdom.Culture.byId(culture).id + "_" + group, s -> {
                    clearScene();
                    SoldierType[] types = SoldierType.values();
                    for (int i = first; i < Math.min(first + 4, types.length); i++) {
                        SoldierEntity e = KingdomModule.SOLDIER.get().create(level(s));
                        e.setup(types[i], player(s).getUUID(), null, 1);
                        e.setCulture(com.alkimor.regnum.kingdom.Culture.byId(selectedCulture));
                        place(e, -6 + (i - first) * 4, 0);
                    }
                    camera(s, 0, -11, 2);
                }, null, 80, false));
            }
        }

        STEPS.add(new Step("31_wall", sv -> {
            clearScene();
            ServerLevel l = level(sv);
            BlockPos hall = new BlockPos(0, Y + 1, -30);
            var city = new com.alkimor.regnum.kingdom.City(java.util.UUID.randomUUID(), player(sv).getUUID(), "Тест", hall);
            city.treasury = 500;
            city.culture = 1;
            var job = com.alkimor.regnum.kingdom.WallJob.plan(List.of(new BlockPos(-14, Y, 8), new BlockPos(0, Y, 8), new BlockPos(14, Y, 8)),
                    List.of(false, true, false), com.alkimor.regnum.kingdom.WallStyle.FORTRESS);
            // достроено две трети: строитель работает на правом краю
            int limit = job.total() * 2 / 3;
            while (job.cell < limit && com.alkimor.regnum.kingdom.Walls.step(l, city, job) != com.alkimor.regnum.kingdom.Walls.Step.DONE) { }
            var hut = KingdomModule.BUILDER_HUT.get().defaultBlockState();
            l.setBlock(new BlockPos(-6, Y + 1, 3), hut, 3);
            net.minecraft.world.entity.npc.Villager b = EntityType.VILLAGER.create(l);
            b.setVillagerData(b.getVillagerData().setProfession(net.minecraft.world.entity.npc.VillagerProfession.MASON).setLevel(2));
            b.setNoAi(true);
            b.setCustomName(net.minecraft.network.chat.Component.literal("Строитель"));
            b.setCustomNameVisible(true);
            place(b, 7, 5);
            camera(sv, 2, -9, 12);
        }, null, 80, false));

        for (int c = 0; c < 6; c++) {
            final int cu = c;
            String cid = com.alkimor.regnum.kingdom.Culture.byId(c).id;
            STEPS.add(new Step("32_capital_" + cid, sv -> {
                clearScene();
                ServerLevel l = level(sv);
                for (int x = -75; x <= 75; x++)
                    for (int z = -75; z <= 75; z++) {
                        l.setBlock(new BlockPos(x, Y, z), Blocks.GRASS_BLOCK.defaultBlockState(), 2);
                        for (int y = Y + 1; y <= Y + 50; y++) l.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 2);
                    }
                var kd = com.alkimor.regnum.kingdom.KingdomData.get(sv);
                var realm = new com.alkimor.regnum.kingdom.Realm(java.util.UUID.randomUUID(), "Тестовое королевство", "правитель", cu, 0, 0);
                kd.addRealm(realm);
                com.alkimor.regnum.kingdom.Realms.buildAt(l, realm, 0, Y, 0);
                for (var e : l.getEntitiesOfClass(com.alkimor.regnum.kingdom.SoldierEntity.class, new net.minecraft.world.phys.AABB(-60, Y - 5, -60, 60, Y + 30, 60))) scene.add(e);
                player(sv).teleportTo(l, 0.5, Y + 62, 108.5, 180f, 32f);
            }, null, 200, false));
            STEPS.add(new Step("33_capital_in_" + cid, sv -> player(sv).teleportTo(level(sv), 0.5, Y + 20, 62.5, 180f, 14f), null, 80, false));
        }

        for (int c = 0; c < 6; c++) {
            final int cu = c;
            STEPS.add(new Step("40_kit_" + com.alkimor.regnum.kingdom.Culture.byId(c).id, sv -> {
                clearScene();
                ServerLevel l = level(sv);
                for (int x = -75; x <= 75; x++)
                    for (int z = -30; z <= 30; z++) {
                        l.setBlock(new BlockPos(x, Y, z), Blocks.GRASS_BLOCK.defaultBlockState(), 2);
                        for (int y = Y + 1; y <= Y + 36; y++) l.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 2);
                    }
                com.alkimor.regnum.kingdom.WallKit.of(cu).showcase(l, -30, 0, 60, true);
                player(sv).teleportTo(l, 0.5, Y + 14, -42.5, 0f, 16f);
            }, null, 160, false));
            STEPS.add(new Step("41_kit_back_" + com.alkimor.regnum.kingdom.Culture.byId(c).id, sv -> {
                player(sv).teleportTo(level(sv), 0.5, Y + 14, 42.5, 180f, 16f);
            }, null, 80, false));
        }

        String[] dts = {"undead_crypt", "creeping_crypt", "toxic_lair", "lone_citadel", "desert_ruins", "bunker", "stray_fort", "witch_villa", "illager_camp"};
        for (String dn : dts) {
            STEPS.add(new Step("50_dt_" + dn, sv -> {
                clearScene();
                com.alkimor.regnum.dungeon.BossHook.lastArena = null;
                ServerLevel l = level(sv);
                var reg = l.registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.STRUCTURE);
                var h = reg.getHolder(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.STRUCTURE, com.alkimor.regnum.Regnum.id("dt/" + dn)));
                if (h.isEmpty()) return;
                var found = l.getChunkSource().getGenerator().findNearestMapStructure(l, net.minecraft.core.HolderSet.direct(h.get()), new BlockPos(0, 64, 0), 120, false);
                if (found == null) return;
                BlockPos at = found.getFirst();
                for (int dx = -9; dx <= 9; dx++)
                    for (int dz = -9; dz <= 9; dz++) l.getChunk((at.getX() >> 4) + dx, (at.getZ() >> 4) + dz);
                com.alkimor.regnum.dungeon.BossHook.flush(l);
                int gy = l.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE, at.getX(), at.getZ());
                DT_AT = at;
                player(sv).teleportTo(l, at.getX() + 0.5, gy + 35, at.getZ() - 55.5, 0f, 30f);
            }, null, 500, false));
            STEPS.add(new Step("51_dt_arena_" + dn, sv -> {
                var a = com.alkimor.regnum.dungeon.BossHook.lastArena;
                if (a != null) player(sv).teleportTo(level(sv), a.getX() + 0.5, a.getY() + 3, a.getZ() - 5.5, 0f, 20f);
            }, null, 300, false));
        }

        // 60: осадные орудия и здания игроков
        STEPS.add(new Step("60_siege", sv -> {
            clearScene();
            ServerLevel l = level(sv);
            for (int x = -50; x <= 50; x++)
                for (int z = -40; z <= 40; z++) {
                    l.setBlock(new BlockPos(x, Y, z), Blocks.GRASS_BLOCK.defaultBlockState(), 2);
                    for (int y = Y + 1; y <= Y + 30; y++) l.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 2);
                }
            for (int x = -40; x <= 40; x++)
                for (int y = Y + 1; y <= Y + 8; y++)
                    for (int z = 18; z <= 20; z++) l.setBlock(new BlockPos(x, y, z), Blocks.STONE_BRICKS.defaultBlockState(), 2);
            var kd = com.alkimor.regnum.kingdom.KingdomData.get(sv);
            var realm = new com.alkimor.regnum.kingdom.Realm(java.util.UUID.randomUUID(), "Осаждающие", "правитель", 1, 0, -200);
            kd.addRealm(realm);
            var cat = KingdomModule.CATAPULT.get().create(l);
            cat.setRealm(realm.id);
            cat.moveTo(-14.5, Y + 1, -8.5, 0f, 0f);
            l.addFreshEntity(cat);
            scene.add(cat);
            var tw = KingdomModule.SIEGE_TOWER.get().create(l);
            tw.setRealm(realm.id);
            tw.moveTo(10.5, Y + 1, 2.5, 0f, 0f);
            l.addFreshEntity(tw);
            scene.add(tw);
            var cv = KingdomModule.CARAVAN.get().create(l);
            cv.moveTo(-3.5, Y + 1, -2.5, 0f, 0f);
            l.addFreshEntity(cv);
            scene.add(cv);
            player(sv).teleportTo(l, -3.5, Y + 6, -22.5, 0f, 10f);
        }, null, 260, false));
        STEPS.add(new Step("60_siege_fire", sv -> {
            ServerLevel l = level(sv);
            for (var e : l.getEntitiesOfClass(com.alkimor.regnum.kingdom.CatapultEntity.class, new net.minecraft.world.phys.AABB(-60, Y - 5, -60, 60, Y + 30, 60))) l.broadcastEntityEvent(e, (byte) 4);
            player(sv).teleportTo(l, -14.5, Y + 3, -20.5, 0f, 8f);
        }, null, 16, false));
        STEPS.add(new Step("60_siege_fire2", sv -> {}, null, 40, false));
        STEPS.add(new Step("61_tower_side", sv -> player(sv).teleportTo(level(sv), 10.5, Y + 6, -14.5, 0f, 12f), null, 100, false));
        String[] bt = {"BARRACKS", "MARKET", "WATCHTOWER", "TRAINING_GROUND", "BUILDER_HUT"};
        for (int bi = 0; bi < bt.length; bi++) {
            final int bix = bi;
            STEPS.add(new Step("62_building_" + bt[bi].toLowerCase(), sv -> {
                clearScene();
                ServerLevel l = level(sv);
                for (int x = -40; x <= 40; x++)
                    for (int z = -40; z <= 40; z++) {
                        l.setBlock(new BlockPos(x, Y, z), Blocks.GRASS_BLOCK.defaultBlockState(), 2);
                        for (int y = Y + 1; y <= Y + 40; y++) l.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 2);
                    }
                var kd = com.alkimor.regnum.kingdom.KingdomData.get(sv);
                var c = new com.alkimor.regnum.kingdom.City(java.util.UUID.randomUUID(), java.util.UUID.randomUUID(), "Витрина", new BlockPos(0, Y, 0));
                c.treasury = 9999;
                c.level = 3;
                c.culture = 0;
                kd.add(c);
                String why = com.alkimor.regnum.kingdom.CityBuildings.raise(l, c, com.alkimor.regnum.kingdom.BuildingType.valueOf(bt[bix]), new BlockPos(0, Y, -20), net.minecraft.core.Direction.SOUTH);
                kd.remove(c);
                com.alkimor.regnum.Regnum.LOGGER.info("[VISUAL] building {} -> {}", bt[bix], why);
                player(sv).teleportTo(l, 0.5, Y + 12, -48.5, 0f, 22f);
            }, null, 120, false));
        }

        STEPS.add(new Step("02_bandits_wanderers", s -> {
            clearScene();
            for (int i = 0; i < 3; i++) {
                BanditEntity b = KingdomModule.BANDIT.get().create(level(s));
                b.setup(i);
                place(b, -6 + i * 2, 0);
            }
            Persona[] ps = {Persona.GUIDE, Persona.TRICKSTER, Persona.HERMIT, Persona.MERCHANT, Persona.NOBLE};
            for (int i = 0; i < ps.length; i++) {
                WandererEntity w = WanderersModule.WANDERER.get().create(level(s));
                w.setup(ps[i]);
                place(w, 1 + i * 2, 0);
            }
            WandererEntity child = WanderersModule.WANDERER.get().create(level(s));
            child.setup(Persona.HEIR);
            child.setChild(true);
            place(child, 0, -2);
            camera(s, 0, -9, 10);
        }, null, 60, false));

        STEPS.add(new Step("02b_army_closeup", s -> {
            clearScene();
            int[][] picks = {{0, 3}, {1, 1}, {2, 3}, {3, 3}, {4, 1}, {5, 3}};
            for (int i = 0; i < picks.length; i++) {
                SoldierEntity e = KingdomModule.SOLDIER.get().create(level(s));
                e.setup(SoldierType.values()[picks[i][1]], player(s).getUUID(), null, 1);
                e.setCulture(com.alkimor.regnum.kingdom.Culture.byId(picks[i][0]));
                place(e, -5 + i * 2, 0);
                e.setYRot(150f + i * 12f);
                e.yBodyRot = 150f + i * 12f;
                e.setYHeadRot(150f + i * 12f);
            }
            camera(s, 0, -5, 12);
        }, null, 60, false));

        bossShot("10_crypt_lord", () -> DungeonModule.CRYPT_LORD.get());
        bossShot("11_mire_mother", () -> RegionsModule.MIRE_MOTHER.get());
        bossShot("12_forgemaster", () -> RegionsModule.FORGEMASTER.get());
        bossShot("13_scarab_queen", () -> RegionsModule.SCARAB_QUEEN.get());
        STEPS.add(new Step(null, s -> {}, () -> originalMineLite = com.alkimor.regnum.core.RegnumClientConfig.LITE_MODE.get(), 1, false));
        mineShot("14_crawler_closeup", com.alkimor.regnum.mine.MineModule.CRAWLER::get, 1.0F, true);
        mineShot("15_crawler_queen_phase1", com.alkimor.regnum.mine.MineModule.CRAWLER_QUEEN::get, 1.0F, true);
        mineShot("16_crawler_queen_phase2", com.alkimor.regnum.mine.MineModule.CRAWLER_QUEEN::get, 0.62F, true);
        mineShot("17_crawler_queen_phase3", com.alkimor.regnum.mine.MineModule.CRAWLER_QUEEN::get, 0.28F, true);
        mineShot("14_crawler_lite", com.alkimor.regnum.mine.MineModule.CRAWLER::get, 1.0F, true);
        mineShot("15_crawler_queen_phase1_lite", com.alkimor.regnum.mine.MineModule.CRAWLER_QUEEN::get, 1.0F, true);
        mineShot("16_crawler_queen_phase2_lite", com.alkimor.regnum.mine.MineModule.CRAWLER_QUEEN::get, 0.62F, true);
        mineShot("17_crawler_queen_phase3_lite", com.alkimor.regnum.mine.MineModule.CRAWLER_QUEEN::get, 0.28F, true);
        broodShot(false);
        broodShot(true);
        STEPS.add(new Step(null, s -> {}, ClientVisualTest::checkMineModels, 1, false));
        STEPS.add(new Step(null, s -> {}, () -> com.alkimor.regnum.core.RegnumClientConfig.LITE_MODE.set(originalMineLite), 1, false));
        STEPS.add(new Step(null, s -> {}, ClientVisualTest::checkAnimationReset, 5, false));

        STEPS.add(new Step("03_blocks", s -> {
            clearScene();
            ServerLevel l = level(s);
            List<Block> blocks = new ArrayList<>();
            for (var h : ModRegistries.BLOCKS.getEntries()) blocks.add(h.get());
            for (int i = 0; i < blocks.size(); i++) {
                l.setBlock(new BlockPos(-blocks.size() + i * 2, Y + 1, 2), blocks.get(i).defaultBlockState(), 3);
            }
            camera(s, 0, -8, 15);
        }, null, 60, false));

        STEPS.add(new Step("04_items_a", s -> giveItems(s, 0), null, 30, true));
        STEPS.add(new Step("05_items_b", s -> giveItems(s, 9), null, 30, true));
        STEPS.add(new Step("06_items_c", s -> giveItems(s, 18), null, 30, true));
        STEPS.add(new Step("07_items_d", s -> giveItems(s, 27), null, 30, true));

        dungeon("crypts", "20_crypt", DungeonModule.CRYPT_ALTAR.get(), 2, -11);
        dungeon("sunken_shrine", "21_shrine", RegionsModule.MIRE_ALTAR.get(), 3, -9);
        dungeon("forge_fortress", "22_fortress", RegionsModule.FORGE_ALTAR.get(), 3, -17);
        dungeon("sand_tomb", "23_tomb", RegionsModule.SUN_ALTAR.get(), 2, -14);
        dungeon("bandit_camps", "24_camp", null, 0, 0);

        STEPS.add(new Step("29_creation", s -> {}, () -> Minecraft.getInstance().setScreen(new com.alkimor.regnum.client.screen.CreationScreen()), 30, true));
        STEPS.add(new Step("30_journal", s -> {
            var p = player(s);
            var d = com.alkimor.regnum.survival.Skills.data(p);
            d.setXp(com.alkimor.regnum.survival.Skill.ONE_HANDED, com.alkimor.regnum.survival.Skill.xpFor(57));
            d.setXp(com.alkimor.regnum.survival.Skill.BOW, com.alkimor.regnum.survival.Skill.xpFor(31));
            d.setXp(com.alkimor.regnum.survival.Skill.LEADERSHIP, com.alkimor.regnum.survival.Skill.xpFor(26));
            d.setXp(com.alkimor.regnum.survival.Skill.ATHLETICS, com.alkimor.regnum.survival.Skill.xpFor(44));
            d.setFocus(com.alkimor.regnum.survival.Skill.ONE_HANDED, 3);
            d.setFocus(com.alkimor.regnum.survival.Skill.BOW, 1);
            d.choose(com.alkimor.regnum.survival.Perk.OH_HEAVY);
            d.addCharXp(9000);
            com.alkimor.regnum.survival.Skills.sync(p, false);
        }, () -> Minecraft.getInstance().setScreen(new JournalScreen()), 30, true));
        STEPS.add(new Step("30b_perks", s -> {}, () -> {
            JournalScreen js = new JournalScreen();
            Minecraft.getInstance().setScreen(js);
            js.openPage(1);
        }, 30, true));
        STEPS.add(new Step("31_city", s -> {}, () -> Minecraft.getInstance().setScreen(new CityScreen(new CityInfoPayload(BlockPos.ZERO,
                "Тестоград", "Князь", 2, 40, 7, 55, 30, 6, 13, 1, 1, 1, 2, false, 1, 60, 20, 12, 6, 3, 2, 1, 32, 1, 5, 1, new int[com.alkimor.regnum.kingdom.SoldierType.values().length], new int[com.alkimor.regnum.core.network.CityInfoPayload.EXTRA_LEN]))), 30, true));
        STEPS.add(new Step("32_command", s -> {}, () -> Minecraft.getInstance().setScreen(new CommandScreen(
                new ArmyInfoPayload(new int[]{6, 3, 2, 1, 0}, new int[]{-1, 0, 2, 3, -1}, 1, 0))), 30, true));
        STEPS.add(new Step("33_trade", s -> {}, () -> Minecraft.getInstance().setScreen(new TradeScreen(new TradeInfoPayload(false, 0L,
                "Рынок города «Тестоград»", "равнины", new int[]{7, 18, 22, 14, 8, 11, 9, 27}, new int[]{5, 12, 15, 10, 6, 8, 7, 19},
                new int[]{0, 2, 0, 0, 1, 0, 0, 0}, new int[]{-1, 1, 0, 0, 0, 0, -1, 1}, 5))), 30, true));
    }

    private static void bossShot(String name, java.util.function.Supplier<EntityType<?>> type) {
        STEPS.add(new Step(name, s -> {
            clearScene();
            Entity e = type.get().create(level(s));
            if (e instanceof Mob m) m.finalizeSpawn(level(s), level(s).getCurrentDifficultyAt(BlockPos.ZERO), MobSpawnType.COMMAND, null);
            place(e, 0, 2);
            e.setYRot(180f);
            if (e instanceof Mob m) {
                m.yBodyRot = 180f;
                m.setYHeadRot(180f);
            }
            SoldierEntity comparison = KingdomModule.SOLDIER.get().create(level(s));
            if (comparison == null) throw new IllegalStateException("Cannot create boss scale reference");
            comparison.setup(SoldierType.SWORDSMAN, player(s).getUUID(), null, 1);
            place(comparison, 3, 2);
            player(s).teleportTo(level(s), -3.5, Y + 4.0, -6.5, -24.0F, 10.0F);
        }, null, 60, false));
    }

    private static void mineShot(String name, java.util.function.Supplier<EntityType<?>> type,
                                 float healthRatio, boolean aggressive) {
        STEPS.add(new Step(name, s -> {
            clearScene();
            ServerLevel level = level(s);
            Entity entity = type.get().create(level);
            if (entity instanceof Mob mob) {
                mob.finalizeSpawn(level, level.getCurrentDifficultyAt(BlockPos.ZERO), MobSpawnType.COMMAND, null);
                mob.setHealth(Math.max(1.0F, mob.getMaxHealth() * healthRatio));
                mob.setAggressive(aggressive);
            }
            place(entity, 0, 2);
            entity.setYRot(180.0F);
            if (entity instanceof Mob mob) {
                mob.yBodyRot = 180.0F;
                mob.setYHeadRot(180.0F);
            }
            boolean queen = entity instanceof com.alkimor.regnum.mine.CrawlerQueenEntity;
            player(s).teleportTo(level, queen ? -3.5 : -1.3, Y + (queen ? 3.0 : 1.6), queen ? -2.5 : -0.7,
                    queen ? -39.0F : -29.0F, queen ? 26.0F : 23.0F);
        }, () -> com.alkimor.regnum.core.RegnumClientConfig.LITE_MODE.set(name.endsWith("_lite")), 40, false));
    }

    private static void checkMineModels() {
        Minecraft mc = Minecraft.getInstance();
        var root = mc.getEntityModels().bakeLayer(com.alkimor.regnum.client.model.CrawlerQueenModel.LAYER);
        var model = new com.alkimor.regnum.client.model.CrawlerQueenModel(root);
        var queen = com.alkimor.regnum.mine.MineModule.CRAWLER_QUEEN.get().create(mc.level);
        if (queen == null) throw new IllegalStateException("Cannot create queen test entity");
        var abdomen = root.getChild("abdomen");
        var fissures = abdomen.getChild("phase_two_fissures");
        var core = abdomen.getChild("phase_three_core");
        for (boolean lite : new boolean[]{false, true}) {
            com.alkimor.regnum.core.RegnumClientConfig.LITE_MODE.set(lite);
            for (float ratio : new float[]{1.0F, 0.62F, 0.28F, 1.0F}) {
                queen.setHealth(queen.getMaxHealth() * ratio);
                model.setupAnim(queen, 2.0F, 0.8F, 30.0F, 15.0F, 8.0F);
                if (fissures.visible != (ratio <= 0.66F) || core.visible != (ratio <= 0.33F))
                    throw new IllegalStateException("Queen phase visibility does not reset, lite=" + lite);
                float expectedSpread = (ratio <= 0.33F ? 0.78F : ratio <= 0.66F ? 0.38F : 0.0F);
                float base = abdomen.getChild("shell_flap_l").getInitialPose().zRot;
                float actual = abdomen.getChild("shell_flap_l").zRot - base;
                if (Math.abs(actual - expectedSpread) > 0.016F)
                    throw new IllegalStateException("Queen shell spread does not match phase");
                for (var part : com.alkimor.regnum.client.model.CrawlerQueenGeometry.decor(root)) {
                    boolean visible = !com.alkimor.regnum.core.RegnumClientConfig.decorHidden();
                    if (part.visible != visible) throw new IllegalStateException("Queen decor does not respect Lite");
                }
                var parts = root.getAllParts().toList();
                float[][] expected = new float[parts.size()][6];
                for (int i = 0; i < parts.size(); i++) {
                    var p = parts.get(i);
                    expected[i] = new float[]{p.x, p.y, p.z, p.xRot, p.yRot, p.zRot};
                }
                for (int frame = 0; frame < 60; frame++) model.setupAnim(queen, 2.0F, 0.8F, 30.0F, 15.0F, 8.0F);
                for (int i = 0; i < parts.size(); i++) {
                    var p = parts.get(i);
                    float[] actualPose = {p.x, p.y, p.z, p.xRot, p.yRot, p.zRot};
                    for (int axis = 0; axis < actualPose.length; axis++)
                        if (!Float.isFinite(actualPose[axis]) || Math.abs(expected[i][axis] - actualPose[axis]) > 0.00001F)
                            throw new IllegalStateException("Queen pose drift: part=" + i + " axis=" + axis);
                }
            }
        }
        log("queen phase transitions/Lite/60 repeated animation frames: OK");
        checkQueenActionPoses(mc);
    }

    /** Input probe for pose assertions; never spawned or used outside the test profile. */
    private static final class QueenPoseProbe extends com.alkimor.regnum.mine.CrawlerQueenEntity {
        int action, elapsed, duration, phase = 1;
        QueenPoseProbe(net.minecraft.world.level.Level level) {
            super(com.alkimor.regnum.mine.MineModule.CRAWLER_QUEEN.get(), level);
            tickCount = 40;
        }
        @Override public int getVisualAction() { return action; }
        @Override public int getVisualActionTicks() { return elapsed; }
        @Override public int getVisualActionDuration() { return duration; }
        @Override public int getVisualPhase() { return phase; }
    }

    private static void checkQueenActionPoses(Minecraft mc) {
        var root = mc.getEntityModels().bakeLayer(com.alkimor.regnum.client.model.CrawlerQueenModel.LAYER);
        var model = new com.alkimor.regnum.client.model.CrawlerQueenModel(root);
        var probe = new QueenPoseProbe(mc.level);
        var head = root.getChild("head");
        var sac = head.getChild("acid_sac_l");
        int[][] clips = {{1, 20, 30}, {1, 23, 30}, {2, 20, 26}, {3, 8, 50}, {4, 12, 24}, {5, 15, 30}, {6, 15, 30}};
        for (int[] clip : clips) {
            probe.action = clip[0]; probe.elapsed = clip[1]; probe.duration = clip[2];
            model.setupAnim(probe, 0, 0, 40, 0, 0);
            if (probe.action == 1 && probe.elapsed < 22 && (sac.xScale <= 1.2F || head.xRot >= -0.2F))
                throw new IllegalStateException("Acid windup not readable");
            if (probe.action == 1 && probe.elapsed > 22 && head.xRot <= 0.05F)
                throw new IllegalStateException("Acid release does not follow tick 22");
            if (probe.action == 3 && head.xRot < 0.4F) throw new IllegalStateException("Stun pose not readable");
            if (probe.action == 4) {
                var rear = root.getChild("leg_rear_l");
                if (rear.zRot - rear.getInitialPose().zRot < 0.2F) throw new IllegalStateException("Brood rear legs do not rise");
            }
            var parts = root.getAllParts().toList();
            float[][] expected = new float[parts.size()][];
            for (int i = 0; i < parts.size(); i++) expected[i] = minePose(parts.get(i));
            for (int frame = 0; frame < 60; frame++) model.setupAnim(probe, 0, 0, 40, 0, 0);
            for (int i = 0; i < parts.size(); i++) {
                float[] actual = minePose(parts.get(i));
                for (int axis = 0; axis < actual.length; axis++)
                    if (!Float.isFinite(actual[axis]) || Math.abs(actual[axis] - expected[i][axis]) > 0.00001F)
                        throw new IllegalStateException("Queen action pose drifts: action=" + probe.action + " part=" + i);
            }
            probe.action = 0; probe.elapsed = 0; probe.duration = 0;
            model.setupAnim(probe, 0, 0, 40, 0, 0);
            if (sac.xScale != 1.0F || sac.yScale != 1.0F) throw new IllegalStateException("Acid sac scale persists after action");
        }
        probe.phase = 3;
        probe.setHealth(probe.getMaxHealth());
        model.setupAnim(probe, 0, 0, 40, 0, 0);
        if (!root.getChild("abdomen").getChild("phase_three_core").visible)
            throw new IllegalStateException("Synced phase lost after healing");
        log("queen acid tick22/charge/stun/brood/cavein/darkness, scale reset, healing phase: OK (pose input probe)");
    }

    private static float[] minePose(net.minecraft.client.model.geom.ModelPart part) {
        return new float[]{part.x, part.y, part.z, part.xRot, part.yRot, part.zRot, part.xScale, part.yScale, part.zScale};
    }

    private static void broodShot(boolean lite) {
        STEPS.add(new Step("18_crawler_brood" + (lite ? "_lite" : ""), s -> {
            clearScene();
            var queen = com.alkimor.regnum.mine.MineModule.CRAWLER_QUEEN.get().create(level(s));
            if (queen == null) throw new IllegalStateException("Cannot create brood queen");
            place(queen, 0, 3);
            for (int[] at : new int[][]{{-3, 0}, {3, 0}, {-3, 5}, {3, 5}}) {
                var crawler = com.alkimor.regnum.mine.MineModule.CRAWLER.get().create(level(s));
                if (crawler == null) throw new IllegalStateException("Cannot create brood crawler");
                place(crawler, at[0], at[1]);
            }
            player(s).teleportTo(level(s), -5.5, Y + 4.0, -7.5, -28.0F, 23.0F);
        }, () -> com.alkimor.regnum.core.RegnumClientConfig.LITE_MODE.set(lite), 40, false));
    }

    /** Same inputs must produce the same pose, including after another entity used the model. */
    private static void checkAnimationReset() {
        Minecraft mc = Minecraft.getInstance();
        var layers = com.alkimor.regnum.client.model.ModelIndex.UNITS;
        for (int culture = 0; culture < layers.length; culture++) {
            for (int role = 0; role < layers[culture].length; role++) {
                var root = mc.getEntityModels().bakeLayer(layers[culture][role]);
                var model = new com.alkimor.regnum.client.render.RegnumHumanoidModel<SoldierEntity>(root, layers[culture][role]);
                var soldier = KingdomModule.SOLDIER.get().create(mc.level);
                if (soldier == null) throw new IllegalStateException("Cannot create animation test soldier");
                soldier.setup(SoldierType.values()[role], java.util.UUID.randomUUID(), null, 1);
                soldier.setCulture(com.alkimor.regnum.kingdom.Culture.byId(culture));
                soldier.hurtTime = 8;
                model.prepareMobModel(soldier, 1.0F, 0.4F, 0.5F);
                model.setupAnim(soldier, 1.0F, 0.4F, 20.0F, 10.0F, 5.0F);
                var parts = root.getAllParts().toList();
                float[][] expected = new float[parts.size()][6];
                for (int i = 0; i < parts.size(); i++) {
                    var p = parts.get(i);
                    expected[i] = new float[]{p.x, p.y, p.z, p.xRot, p.yRot, p.zRot};
                }
                for (int frame = 0; frame < 60; frame++) model.setupAnim(soldier, 1.0F, 0.4F, 20.0F, 10.0F, 5.0F);
                for (int i = 0; i < parts.size(); i++) {
                    var p = parts.get(i);
                    float[] actual = {p.x, p.y, p.z, p.xRot, p.yRot, p.zRot};
                    for (int axis = 0; axis < actual.length; axis++)
                        if (!Float.isFinite(actual[axis]) || Math.abs(expected[i][axis] - actual[axis]) > 0.00001F)
                            throw new IllegalStateException("Pose drifts: culture=" + culture + " role=" + role + " part=" + i + " axis=" + axis);
                }
            }
        }
        log("pose reset OK: 84 culture/role models, 60 repeated frames each");
    }

    private static BlockPos found;

    private static void dungeon(String tag, String name, Block altar, int camUp, int camBack) {
        STEPS.add(new Step(name + "_outside", s -> {
            clearScene();
            ServerLevel l = level(s);
            found = l.findNearestMapStructure(TagKey.create(Registries.STRUCTURE, Regnum.id(tag)), BlockPos.ZERO, 150, false);
            if (found == null) {
                log("structure not found: " + tag);
                return;
            }
            l.getChunk(found.getX() >> 4, found.getZ() >> 4);
            int top = l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, found.getX(), found.getZ());
            log(tag + " at " + found.getX() + " " + top + " " + found.getZ());
            player(s).teleportTo(l, found.getX() + 0.5, top + 22, found.getZ() - 26, 0f, 38f);
        }, null, 220, false));
        if (altar == null) return;
        STEPS.add(new Step(name + "_inside", s -> {
            if (found == null) return;
            ServerLevel l = level(s);
            BlockPos a = null;
            for (int cx = -2; cx <= 4; cx++) for (int cz = -2; cz <= 6; cz++) l.getChunk((found.getX() >> 4) + cx - 1, (found.getZ() >> 4) + cz - 1);
            int top = l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, found.getX(), found.getZ());
            outer:
            for (int y = top + 8; y > top - 40; y--)
                for (int dz = -32; dz <= 64; dz++)
                    for (int dx = -32; dx <= 32; dx++) {
                        BlockPos p = new BlockPos(found.getX() + dx, y, found.getZ() + dz);
                        if (l.getBlockState(p).is(altar)) {
                            a = p;
                            break outer;
                        }
                    }
            if (a == null) {
                log("altar not found for " + name);
                return;
            }
            log(name + " altar at " + a.toShortString());
            player(s).teleportTo(l, a.getX() + 0.5, a.getY() + camUp, a.getZ() + camBack + 0.5, 0f, 12f);
        }, null, 140, false));
    }

    // ================================================================== помощники сцены

    private static ServerLevel level(MinecraftServer s) {
        return s.overworld();
    }

    private static ServerPlayer player(MinecraftServer s) {
        return s.getPlayerList().getPlayers().get(0);
    }

    private static void place(Entity e, int x, int z) {
        e.moveTo(x + 0.5, Y + 1, z + 0.5, 180f, 0f);
        if (e instanceof Mob m) {
            m.setNoAi(true);
            m.setYHeadRot(180f);
            m.yBodyRot = 180f;
            m.setPersistenceRequired();
        }
        e.level().addFreshEntity(e);
        scene.add(e);
    }

    private static void clearScene() {
        for (Entity e : scene) e.discard();
        scene.clear();
        // A quick-play test world can load the previous run's persistent subjects
        // after the initial login cleanup. Remove them before each arena shot.
        if (sceneLevel != null) {
            for (Entity e : sceneLevel.getEntities((Entity) null,
                    new net.minecraft.world.phys.AABB(-25, Y - 2, -25, 25, Y + 15, 25),
                    e -> !(e instanceof net.minecraft.world.entity.player.Player))) e.discard();
        }
    }

    private static void camera(MinecraftServer s, int x, int z, float pitch) {
        player(s).teleportTo(level(s), x + 0.5, Y + 1, z + 0.5, 0f, pitch);
    }

    private static void setupWorld(MinecraftServer s) {
        ServerLevel l = level(s);
        sceneLevel = l;
        ServerPlayer p = player(s);
        p.setGameMode(GameType.CREATIVE);
        l.setDayTime(6000);
        l.setWeatherParameters(999999, 0, false, false);
        l.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false, s);
        l.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(false, s);
        p.getAbilities().invulnerable = true;
        p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 20 * 60 * 60, 0, false, false));
        p.getAbilities().flying = true;
        p.onUpdateAbilities();
        // площадка для съёмки в небе
        for (int x = -20; x <= 20; x++)
            for (int z = -20; z <= 20; z++) {
                l.setBlock(new BlockPos(x, Y, z), (x + z) % 7 == 0 ? Blocks.MOSS_BLOCK.defaultBlockState() : Blocks.GRASS_BLOCK.defaultBlockState(), 3);
                for (int y = Y + 1; y <= Y + 12; y++) l.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 3);
            }
        camera(s, 0, -7, 10);
    }

    private static void giveItems(MinecraftServer s, int from) {
        clearScene();
        ServerPlayer p = player(s);
        List<Item> items = new ArrayList<>();
        for (var h : ModRegistries.ITEMS.getEntries()) items.add(h.get());
        for (int i = 0; i < 9; i++) {
            int k = from + i;
            p.getInventory().setItem(i, k < items.size() ? new ItemStack(items.get(k)) : ItemStack.EMPTY);
        }
        p.getInventory().selected = 4;
    }

    // ================================================================== цикл

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post event) {
        if (!enabled()) return;
        Minecraft mc = Minecraft.getInstance();
        // Screen captures and reviewing other windows must not pause the test world.
        // This changes only this explicitly enabled test process, without saving options.
        mc.options.pauseOnLostFocus = false;
        if (mc.screen instanceof net.minecraft.client.gui.screens.PauseScreen) {
            mc.setScreen(null);
            return;
        }
        if (mc.screen instanceof net.minecraft.client.gui.screens.AccessibilityOnboardingScreen onboarding) {
            log("completing first-launch onboarding in visual test profile");
            onboarding.onClose();
            return;
        }
        if (mc.player == null || mc.level == null || mc.getSingleplayerServer() == null) return;
        if (mc.player.isDeadOrDying()) {
            mc.player.respawn();
            return;
        }
        if (readyTicks == 0) {
            MinecraftServer server = mc.getSingleplayerServer();
            server.execute(() -> {
                ServerPlayer p = player(server);
                p.setGameMode(GameType.CREATIVE);
                p.getAbilities().invulnerable = true;
                p.onUpdateAbilities();
                List<Entity> all = new ArrayList<>();
                level(server).getAllEntities().forEach(all::add);
                for (Entity e : all) {
                    if (!(e instanceof net.minecraft.world.entity.player.Player)) e.discard();
                }
            });
        }
        if (readyTicks < 100) {
            readyTicks++;
            return;
        }
        if (STEPS.isEmpty()) {
            build();
            String only = System.getProperty("regnum.visualonly");
            try {
                java.nio.file.Path f = mc.gameDirectory.toPath().resolve("visualonly.txt");
                if ((only == null || only.isBlank()) && java.nio.file.Files.exists(f)) only = java.nio.file.Files.readString(f).trim();
            } catch (Exception ignored) {
            }
            if (only != null && !only.isBlank()) {
                String[] pre = only.split(",");
                List<Step> keep = new ArrayList<>();
                for (int i = 0; i < STEPS.size(); i++) {
                    Step s = STEPS.get(i);
                    boolean k = i == 0 || s.name() == null;
                    for (String p : pre) if (s.name() != null && s.name().startsWith(p.trim())) k = true;
                    if (k) keep.add(s);
                }
                STEPS.clear();
                STEPS.addAll(keep);
            }
        }
        try {
            if (serverFailure != null) {
                Regnum.LOGGER.error("[REGNUM-VISUAL] RESULT: FAIL — server step", serverFailure);
                mc.stop();
                return;
            }
            if (!serverReady) return;
            if (pendingClient != null) {
                Runnable action = pendingClient;
                pendingClient = null;
                action.run();
            }
            if (index < 0 || timer <= 0) {
                if (shotPending) {
                    Step prev = STEPS.get(index);
                    if (!prev.gui() && mc.screen != null)
                        throw new IllegalStateException("World screenshot obstructed by " + mc.screen.getClass().getSimpleName());
                    Screenshot.grab(mc.gameDirectory, prev.name() + ".png", mc.getMainRenderTarget(), msg -> {});
                    log("screenshot " + prev.name());
                    shotPending = false;
                    if (mc.screen != null) mc.setScreen(null);
                }
                index++;
                if (index >= STEPS.size()) {
                    log("RESULT: OK — сценарий завершён");
                    mc.stop();
                    return;
                }
                Step st = STEPS.get(index);
                mc.options.hideGui = !st.gui();
                MinecraftServer server = mc.getSingleplayerServer();
                serverReady = false;
                pendingClient = st.client();
                server.execute(() -> {
                    try {
                        st.server().accept(server);
                    } catch (Throwable t) {
                        Regnum.LOGGER.error("[REGNUM-VISUAL] step failed: " + st.name(), t);
                        serverFailure = t;
                    } finally {
                        serverReady = true;
                    }
                });
                timer = st.delay();
                shotPending = st.name() != null;
            } else {
                timer--;
            }
        } catch (Throwable t) {
            Regnum.LOGGER.error("[REGNUM-VISUAL] RESULT: FAIL", t);
            mc.stop();
        }
    }

    @SuppressWarnings("unused")
    private static ResourceLocation rl(String p) {
        return Regnum.id(p);
    }

    @SuppressWarnings("unused")
    private static TagKey<Structure> unused() {
        return null;
    }
}
