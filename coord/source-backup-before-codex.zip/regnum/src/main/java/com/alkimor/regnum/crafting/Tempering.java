package com.alkimor.regnum.crafting;

import com.alkimor.regnum.core.InvUtil;
import com.alkimor.regnum.core.Text;
import com.alkimor.regnum.dungeon.DungeonModule;
import com.alkimor.regnum.survival.Skill;
import com.alkimor.regnum.survival.Skills;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MaceItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TridentItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Закалка: каждая ступень даёт +1 к урону оружия или +1 к броне.
 * Шанс успеха зависит от навыка «Кузнечное дело» и текущей ступени.
 */
public final class Tempering {
    private Tempering() {}

    public static final int MAX_TEMPER = 5;
    /** Минимальный уровень кузнеца для перехода на ступень (индекс = целевая ступень). */
    private static final int[] REQUIRED_LEVEL = {0, 0, 0, 1, 3, 5};

    public record Cost(Item item, int count) {}

    public static boolean isTemperable(ItemStack stack) {
        Item i = stack.getItem();
        return i instanceof SwordItem || i instanceof AxeItem || i instanceof TridentItem || i instanceof MaceItem || i instanceof ArmorItem;
    }

    public static int temper(ItemStack stack) {
        return stack.getOrDefault(CraftingModule.TEMPER.get(), 0);
    }

    public static List<Cost> costFor(int target) {
        List<Cost> c = new ArrayList<>();
        switch (target) {
            case 1, 2 -> c.add(new Cost(Items.IRON_INGOT, 3));
            case 3 -> { c.add(new Cost(Items.IRON_INGOT, 3)); c.add(new Cost(Items.GOLD_INGOT, 2)); }
            case 4 -> { c.add(new Cost(Items.DIAMOND, 1)); c.add(new Cost(Items.GOLD_INGOT, 2)); }
            default -> { c.add(new Cost(DungeonModule.CRYPT_HEART.get(), 1)); c.add(new Cost(Items.DIAMOND, 2)); }
        }
        return c;
    }

    public static float chance(int target, int smithLevel) {
        float c = 0.95f - 0.15f * (target - 1) + 0.04f * smithLevel;
        return Math.max(0.1f, Math.min(0.98f, c));
    }

    public static String describeCost(List<Cost> cost) {
        StringBuilder sb = new StringBuilder();
        for (Cost c : cost) {
            if (!sb.isEmpty()) sb.append(" + ");
            sb.append(c.count()).append("× ").append(c.item().getDescription().getString());
        }
        return sb.toString();
    }

    public static void attempt(ServerPlayer player, ItemStack stack, ServerLevel level, BlockPos pos) {
        int cur = temper(stack);
        if (cur >= MAX_TEMPER) {
            Text.info(player, "Этот предмет уже закалён до предела.");
            return;
        }
        int target = cur + 1;
        int lvl = Skills.level(player, Skill.SMITHING);
        if (lvl < REQUIRED_LEVEL[target]) {
            Text.bad(player, "Для закалки до ступени " + target + " нужен уровень кузнеца " + REQUIRED_LEVEL[target] + " (у вас " + lvl + ").");
            return;
        }
        List<Cost> cost = costFor(target);
        for (Cost c : cost) {
            if (!player.getAbilities().instabuild && InvUtil.count(player, c.item()) < c.count()) {
                Text.bad(player, "Не хватает материалов: " + describeCost(cost));
                return;
            }
        }
        for (Cost c : cost) InvUtil.take(player, c.item(), c.count());

        float ch = chance(target, lvl);
        if (player.getRandom().nextFloat() < ch) {
            stack.set(CraftingModule.TEMPER.get(), target);
            level.playSound(null, pos, SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 1f, 1.1f);
            level.sendParticles(ParticleTypes.LAVA, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 8, 0.2, 0.1, 0.2, 0.0);
            Text.good(player, "Удача! «" + stack.getHoverName().getString() + "» закалён до ступени " + target + ".");
            Skills.addXp(player, Skill.SMITHING, 15 * target);
        } else {
            level.playSound(null, pos, SoundEvents.ANVIL_DESTROY, SoundSource.BLOCKS, 0.8f, 0.9f);
            level.sendParticles(ParticleTypes.LARGE_SMOKE, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 10, 0.2, 0.1, 0.2, 0.01);
            if (cur >= 3 && player.getRandom().nextFloat() < 0.3f) {
                stack.set(CraftingModule.TEMPER.get(), cur - 1);
                Text.bad(player, "Металл треснул! Закалка упала до ступени " + (cur - 1) + ".");
            } else {
                Text.bad(player, "Неудача — материалы испорчены. (шанс был " + Math.round(ch * 100) + "%)");
            }
            Skills.addXp(player, Skill.SMITHING, 5 + 2 * target);
        }
    }

    public static void showInfo(ServerPlayer player, ItemStack held) {
        int lvl = Skills.level(player, Skill.SMITHING);
        player.sendSystemMessage(Text.of("⚒ Горн мастера — Кузнечное дело: " + lvl + " ур.", ChatFormatting.GOLD));
        Text.info(player, "Возьмите в руку меч, топор, трезубец, булаву или броню и нажмите ПКМ по горну.");
        for (int t = 1; t <= MAX_TEMPER; t++) {
            String req = REQUIRED_LEVEL[t] > 0 ? " [нужен ур. " + REQUIRED_LEVEL[t] + "]" : "";
            player.sendSystemMessage(Text.of("  Ступень " + t + ": " + describeCost(costFor(t)) + " — шанс " + Math.round(chance(t, lvl) * 100) + "%" + req,
                    lvl >= REQUIRED_LEVEL[t] ? ChatFormatting.GRAY : ChatFormatting.DARK_GRAY));
        }
    }
}
