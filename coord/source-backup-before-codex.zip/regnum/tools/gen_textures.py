"""Генератор оригинальных пиксельных текстур Regnum (16x16, эффекты 18x18).
Запуск: python3 tools/gen_textures.py  (из корня проекта)
"""
import random
from PIL import Image

ROOT = "src/main/resources/assets/regnum/textures"
T = (0, 0, 0, 0)


def hexc(h, a=255):
    h = h.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3]) + (c[3],)


def new(size=16):
    return Image.new("RGBA", (size, size), T)


def px(img, x, y, c):
    if 0 <= x < img.width and 0 <= y < img.height:
        img.putpixel((x, y), c)


def line(img, pts, c):
    for (x, y) in pts:
        px(img, x, y, c)


def rect(img, x0, y0, x1, y1, c):
    for x in range(x0, x1 + 1):
        for y in range(y0, y1 + 1):
            px(img, x, y, c)


def outline(img, c=hexc('#1a1410')):
    """Тёмный контур вокруг непрозрачных пикселей (стиль ванильных предметов)."""
    src = img.copy()
    for x in range(img.width):
        for y in range(img.height):
            if src.getpixel((x, y))[3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < img.width and 0 <= ny < img.height and src.getpixel((nx, ny))[3] > 0 \
                            and src.getpixel((nx, ny)) != c:
                        img.putpixel((x, y), c)
                        break
    return img


def noise_fill(img, base, var=0.12, seed=1, region=None):
    rnd = random.Random(seed)
    x0, y0, x1, y1 = region or (0, 0, img.width - 1, img.height - 1)
    for x in range(x0, x1 + 1):
        for y in range(y0, y1 + 1):
            px(img, x, y, shade(base, 1 + rnd.uniform(-var, var)))


def save(img, path):
    img.save(f"{ROOT}/{path}.png")


# ============================================================ ПРЕДМЕТЫ

def item_baton():
    img = new()
    wood, wood_d, gold, gold_l, red = hexc('#6b4423'), hexc('#4a2e17'), hexc('#d9a62b'), hexc('#ffe27a'), hexc('#a8231f')
    for i in range(3, 13):
        px(img, i, 15 - i, wood); px(img, i + 1, 15 - i, wood_d)
    rect(img, 11, 2, 13, 4, gold); px(img, 12, 3, red); px(img, 11, 2, gold_l); px(img, 13, 1, gold); px(img, 14, 2, gold)
    rect(img, 2, 12, 3, 13, gold); px(img, 2, 12, gold_l)
    px(img, 7, 8, gold); px(img, 8, 7, gold)
    return outline(img)


def item_bandage():
    img = new()
    w, w2, w3, red = hexc('#f2efe6'), hexc('#d8d2c2'), hexc('#b9b19c'), hexc('#c0392b')
    for y in range(4, 12):
        for x in range(3, 13):
            if (x - 8) ** 2 / 25 + (y - 8) ** 2 / 16 <= 1:
                px(img, x, y, w if (x + y) % 3 else w2)
    for y in range(5, 11):
        px(img, 8, y, w3)
    rect(img, 10, 7, 14, 9, w2); px(img, 14, 8, w3)
    px(img, 5, 6, red); px(img, 4, 7, red); px(img, 5, 7, red); px(img, 6, 7, red); px(img, 5, 8, red)
    return outline(img)


def item_splint():
    img = new()
    wood, wood_d, cloth = hexc('#9c7a4a'), hexc('#6e5430'), hexc('#ece6d6')
    for y in range(1, 15):
        px(img, 5, y, wood); px(img, 6, y, wood_d); px(img, 9, y, wood); px(img, 10, y, wood_d)
    for y in (3, 4, 8, 9, 12, 13):
        rect(img, 5, y, 10, y, cloth)
    return outline(img)


def potion(liquid, hi, cork=hexc('#8a6a3a')):
    img = new()
    glass, glass_d = hexc('#cfe3ea', 200), hexc('#9fb8c2', 220)
    rect(img, 7, 1, 8, 2, cork)
    rect(img, 6, 3, 9, 4, glass_d)
    for y in range(5, 15):
        for x in range(3, 13):
            if (x - 7.5) ** 2 / 20 + (y - 10) ** 2 / 22 <= 1:
                px(img, x, y, glass)
    for y in range(8, 15):
        for x in range(3, 13):
            if (x - 7.5) ** 2 / 17 + (y - 10) ** 2 / 19 <= 1:
                px(img, x, y, liquid if (x + y) % 4 else hi)
    px(img, 5, 7, hexc('#ffffff')); px(img, 5, 8, hexc('#ffffff'))
    return outline(img)


def item_medkit():
    img = new()
    box, box_d, white, handle = hexc('#c23b2e'), hexc('#8e2219'), hexc('#f5f1e8'), hexc('#3a2a20')
    rect(img, 2, 5, 13, 13, box); rect(img, 2, 13, 13, 13, box_d); rect(img, 13, 5, 13, 13, box_d)
    rect(img, 6, 3, 9, 3, handle); px(img, 6, 4, handle); px(img, 9, 4, handle)
    rect(img, 7, 6, 8, 12, white); rect(img, 5, 8, 10, 10, white)
    return outline(img)


def item_herb():
    img = new()
    g1, g2, g3, stem, fl = hexc('#4f8a2e'), hexc('#6fb23e'), hexc('#2f5c1b'), hexc('#5a7a2a'), hexc('#e8e070')
    for y in range(6, 15):
        px(img, 8, y, stem)
    leaves = [(6, 5), (5, 6), (6, 6), (7, 7), (10, 6), (11, 5), (10, 5), (9, 7), (5, 9), (6, 10), (7, 10), (11, 9), (10, 10), (9, 10),
              (4, 8), (12, 8)]
    for i, (x, y) in enumerate(leaves):
        px(img, x, y, [g1, g2, g3][i % 3])
    px(img, 8, 3, fl); px(img, 7, 4, fl); px(img, 9, 4, fl); px(img, 8, 4, hexc('#f0a030'))
    return outline(img)


def item_journal():
    img = new()
    cover, cover_d, page, strap, gold = hexc('#5c3a21'), hexc('#3e2614'), hexc('#efe4c8'), hexc('#2a1c10'), hexc('#d9a62b')
    rect(img, 3, 2, 12, 14, cover); rect(img, 3, 2, 3, 14, cover_d)
    rect(img, 12, 3, 13, 13, page)
    rect(img, 5, 5, 10, 5, gold); rect(img, 5, 7, 9, 7, gold)
    rect(img, 9, 9, 13, 10, strap); px(img, 11, 9, gold)
    return outline(img)


def item_scroll():
    img = new()
    paper, paper_d, roll, seal = hexc('#f1e3bd'), hexc('#d6c193'), hexc('#b89a5e'), hexc('#a8231f')
    rect(img, 4, 3, 11, 12, paper)
    for y in (5, 7, 9):
        rect(img, 5, y, 10, y, paper_d)
    rect(img, 3, 2, 12, 2, roll); rect(img, 3, 13, 12, 13, roll)
    px(img, 2, 2, roll); px(img, 13, 13, roll)
    rect(img, 9, 10, 10, 11, seal)
    return outline(img)


def item_crypt_heart():
    img = new()
    c1, c2, c3, glow = hexc('#5b2a86'), hexc('#8a4fd0'), hexc('#2e1247'), hexc('#d6b0ff')
    heart = ["..XX..XX..", ".XXXXXXXX.", "XXXXXXXXXX", "XXXXXXXXXX", ".XXXXXXXX.", "..XXXXXX..", "...XXXX...", "....XX...."]
    for j, row in enumerate(heart):
        for i, ch in enumerate(row):
            if ch == 'X':
                x, y = i + 3, j + 4
                px(img, x, y, c2 if (i + j) % 3 else c1)
    for (x, y) in [(5, 6), (6, 5), (5, 5)]:
        px(img, x, y, glow)
    for (x, y) in [(8, 7), (9, 8), (10, 9), (8, 9), (9, 10)]:
        px(img, x, y, c3)
    px(img, 7, 2, glow); px(img, 12, 3, glow); px(img, 3, 3, c2)
    return outline(img)


def item_blade():
    img = new()
    steel, steel_l, steel_d, purple, guard, grip, gem = hexc('#3d3a4a'), hexc('#8e86a8'), hexc('#1f1c29'), hexc('#7b2fbe'), hexc('#c9a227'), hexc('#2b1a12'), hexc('#c46bff')
    for i in range(0, 10):
        x, y = 4 + i, 11 - i
        px(img, x, y, steel); px(img, x + 1, y, steel_l if i % 2 else steel); px(img, x, y - 1, steel_d)
        if i % 3 == 1:
            px(img, x + 1, y - 1, purple)
    px(img, 14, 1, steel_l); px(img, 15, 0, steel_l)
    for (x, y) in [(2, 10), (3, 11), (4, 12), (5, 13), (6, 14)]:
        px(img, x, y, guard)
    px(img, 4, 12, gem)
    for i in range(3):
        px(img, 3 - i, 13 + i, grip)
    px(img, 0, 15, guard)
    return outline(img)


def item_elixir():
    return potion(hexc('#7fbf3f'), hexc('#c7e86a'))


# ============================================================ БЛОКИ

def planks(img, seed, base=hexc('#8a6238')):
    noise_fill(img, base, 0.08, seed)
    for y in (3, 7, 11, 15):
        rect(img, 0, y, 15, y, shade(base, 0.7))


def bricks(img, seed, base=hexc('#8f8f8f')):
    noise_fill(img, base, 0.07, seed)
    mortar = shade(base, 0.62)
    for y in (3, 7, 11, 15):
        rect(img, 0, y, 15, y, mortar)
    for row in range(4):
        off = 0 if row % 2 == 0 else 4
        for x in range(off, 16, 8):
            for y in range(row * 4, row * 4 + 3):
                px(img, x, y, mortar)


def block_town_hall():
    side = new(); bricks(side, 11, hexc('#bdb6a3'))
    rect(side, 0, 0, 15, 2, hexc('#7a2a20')); rect(side, 0, 2, 15, 2, hexc('#5a1c14'))
    rect(side, 6, 5, 9, 15, hexc('#4a2e17')); rect(side, 7, 6, 8, 15, hexc('#6b4423')); px(side, 8, 11, hexc('#d9a62b'))
    rect(side, 2, 6, 3, 9, hexc('#3d6fa8')); rect(side, 12, 6, 13, 9, hexc('#3d6fa8'))
    rect(side, 7, 3, 8, 4, hexc('#d9a62b'))
    top = new(); noise_fill(top, hexc('#8e2f22'), 0.08, 12)
    for i in range(16):
        px(top, i, i, hexc('#6a2016')); px(top, 15 - i, i, hexc('#6a2016'))
    rect(top, 6, 6, 9, 9, hexc('#d9a62b')); rect(top, 7, 7, 8, 8, hexc('#ffe27a'))
    return side, top


def block_barracks():
    side = new(); planks(side, 21, hexc('#7a5230'))
    rect(side, 0, 0, 0, 15, hexc('#4a2e17')); rect(side, 15, 0, 15, 15, hexc('#4a2e17'))
    # скрещённые мечи
    for i in range(3, 13):
        px(side, i, i, hexc('#c8c8d0')); px(side, 15 - i, i, hexc('#c8c8d0'))
    rect(side, 3, 11, 4, 12, hexc('#d9a62b')); rect(side, 11, 11, 12, 12, hexc('#d9a62b'))
    rect(side, 6, 5, 9, 9, hexc('#a8231f')); rect(side, 7, 6, 8, 8, hexc('#d9a62b'))
    top = new(); planks(top, 22, hexc('#6b4423'))
    rect(top, 3, 3, 12, 12, hexc('#a8231f')); rect(top, 5, 5, 10, 10, hexc('#7d1814'))
    return side, top


def block_market():
    side = new(); planks(side, 31, hexc('#9a7444'))
    for x in range(16):
        c = hexc('#e8e0cc') if (x // 2) % 2 == 0 else hexc('#2e8a4a')
        rect(side, x, 0, x, 4, c)
    rect(side, 0, 5, 15, 5, hexc('#4a2e17'))
    rect(side, 3, 9, 5, 11, hexc('#2fbf6a')); rect(side, 10, 9, 12, 11, hexc('#d9a62b'))
    px(side, 4, 10, hexc('#8af0b0')); px(side, 11, 10, hexc('#ffe27a'))
    rect(side, 1, 12, 14, 12, hexc('#5a3a1e'))
    top = new()
    for x in range(16):
        for y in range(16):
            px(top, x, y, hexc('#e8e0cc') if ((x // 4) + (y // 4)) % 2 == 0 else hexc('#2e8a4a'))
    return side, top


def block_watchtower():
    side = new(); bricks(side, 41, hexc('#8a8a86'))
    rect(side, 0, 0, 15, 3, hexc('#6b6b67'))
    for x in (1, 5, 9, 13):
        rect(side, x, 0, x + 1, 1, T if False else hexc('#4d4d4a'))
    rect(side, 7, 6, 8, 10, hexc('#1c1c1c')); px(side, 7, 6, hexc('#f0b030'))
    top = new(); noise_fill(top, hexc('#7a7a76'), 0.08, 42)
    rect(top, 0, 0, 15, 1, hexc('#555551')); rect(top, 0, 14, 15, 15, hexc('#555551'))
    rect(top, 0, 0, 1, 15, hexc('#555551')); rect(top, 14, 0, 15, 15, hexc('#555551'))
    rect(top, 7, 7, 8, 8, hexc('#f0b030'))
    return side, top


def block_forge():
    side = new(); bricks(side, 51, hexc('#5e4a40'))
    rect(side, 4, 7, 11, 13, hexc('#1a1210'))
    for x in range(5, 11):
        px(side, x, 12, hexc('#ff7a1a')); px(side, x, 11, hexc('#ffb53a') if x % 2 else hexc('#ff7a1a'))
    px(side, 7, 10, hexc('#ffe27a')); px(side, 8, 9, hexc('#ffb53a'))
    rect(side, 3, 6, 12, 6, hexc('#3a2a24'))
    top = new(); noise_fill(top, hexc('#3a3a3e'), 0.08, 52)
    rect(top, 2, 5, 13, 10, hexc('#55555a')); rect(top, 4, 4, 11, 4, hexc('#55555a')); rect(top, 12, 6, 14, 8, hexc('#55555a'))
    rect(top, 3, 6, 12, 6, hexc('#77777e'))
    return side, top


def block_altar():
    side = new(); noise_fill(side, hexc('#2a2630'), 0.1, 61)
    rect(side, 0, 0, 15, 2, hexc('#3d3647')); rect(side, 0, 13, 15, 15, hexc('#3d3647'))
    for (x, y) in [(4, 6), (5, 7), (6, 8), (9, 8), (10, 7), (11, 6), (7, 9), (8, 9), (7, 5), (8, 5)]:
        px(side, x, y, hexc('#7b2fbe'))
    top = new(); noise_fill(top, hexc('#2a2630'), 0.1, 62)
    rune = hexc('#9b4fff')
    for i in range(3, 13):
        px(top, i, 3, rune); px(top, i, 12, rune); px(top, 3, i, rune); px(top, 12, i, rune)
    for i in range(5, 11):
        px(top, i, i, rune); px(top, 15 - i, i, rune)
    rect(top, 7, 7, 8, 8, hexc('#e0c0ff'))
    top_off = top.copy()
    for x in range(16):
        for y in range(16):
            c = top_off.getpixel((x, y))
            if c[:3] in ((0x9b, 0x4f, 0xff), (0xe0, 0xc0, 0xff)):
                top_off.putpixel((x, y), hexc('#3d3647'))
    return side, top, top_off


# ============================================================ ЭФФЕКТЫ (18x18)

def effect_bleeding():
    img = new(18)
    red, red_d, hi = hexc('#c0141c'), hexc('#7a0a10'), hexc('#ff6a6a')
    for y in range(3, 16):
        for x in range(4, 14):
            w = (y - 3) * 0.45 if y < 10 else 4.5 - (y - 10) * 0.6
            if abs(x - 8.5) <= max(0.5, w):
                px(img, x, y, red if x < 10 else red_d)
    px(img, 7, 9, hi); px(img, 7, 10, hi)
    return outline(img)


def effect_fracture():
    img = new(18)
    bone, bone_d = hexc('#efe8d6'), hexc('#bdb39a')
    for i in range(3, 15):
        px(img, i, i, bone); px(img, i + 1, i, bone_d)
    for (x, y) in [(2, 3), (3, 2), (2, 2), (15, 14), (14, 15), (15, 15)]:
        px(img, x, y, bone)
    for (x, y) in [(8, 9), (9, 8), (10, 7), (8, 10)]:
        px(img, x, y, T)
    px(img, 9, 9, hexc('#c0141c'))
    return outline(img)


def effect_infection():
    img = new(18)
    g, g_d, g_l = hexc('#6f9a1e'), hexc('#3e5a0e'), hexc('#b6e04a')
    for y in range(18):
        for x in range(18):
            if (x - 8.5) ** 2 + (y - 8.5) ** 2 <= 30:
                px(img, x, y, g if (x * 3 + y) % 5 else g_d)
    for (x, y) in [(6, 6), (11, 7), (7, 11), (10, 11)]:
        px(img, x, y, g_l); px(img, x + 1, y, g_l)
    for (x, y) in [(8, 2), (8, 1), (15, 8), (16, 8), (8, 15), (8, 16), (2, 8), (1, 8)]:
        px(img, x, y, g_d)
    return outline(img)


if __name__ == "__main__":
    import os
    for d in ("item", "block", "mob_effect"):
        os.makedirs(f"{ROOT}/{d}", exist_ok=True)
    items = {
        "commander_baton": item_baton(), "bandage": item_bandage(), "splint": item_splint(),
        "herbal_decoction": potion(hexc('#3f8a4a'), hexc('#7fd08a')), "medkit": item_medkit(),
        "healing_herb": item_herb(), "survivor_journal": item_journal(), "mastery_scroll": item_scroll(),
        "crypt_heart": item_crypt_heart(), "morgrath_blade": item_blade(), "trick_elixir": item_elixir(),
    }
    for k, v in items.items():
        save(v, f"item/{k}")
    for name, fn in (("town_hall", block_town_hall), ("barracks", block_barracks), ("market", block_market),
                     ("watchtower", block_watchtower), ("master_forge", block_forge)):
        side, top = fn()
        save(side, f"block/{name}_side")
        save(top, f"block/{name}_top")
    side, top, top_off = block_altar()
    save(side, "block/crypt_altar_side"); save(top, "block/crypt_altar_top"); save(top_off, "block/crypt_altar_top_used")
    save(effect_bleeding(), "mob_effect/bleeding")
    save(effect_fracture(), "mob_effect/fracture")
    save(effect_infection(), "mob_effect/infection")
    print("ok")
