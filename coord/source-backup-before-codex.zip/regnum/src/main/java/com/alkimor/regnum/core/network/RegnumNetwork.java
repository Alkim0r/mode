package com.alkimor.regnum.core.network;

import com.alkimor.regnum.client.ClientAccess;
import com.alkimor.regnum.kingdom.ArmyCommands;
import com.alkimor.regnum.kingdom.CityActions;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Регистрация всех пакетов. Клиентские обработчики вызывают {@link ClientAccess}
 * только внутри лямбды — на выделенном сервере этот класс не загружается.
 */
public final class RegnumNetwork {
    private RegnumNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar r = event.registrar("1");

        r.playToClient(SkillSyncPayload.TYPE, SkillSyncPayload.CODEC,
                (p, ctx) -> ctx.enqueueWork(() -> ClientAccess.onSkillSync(p)));
        r.playToClient(CityInfoPayload.TYPE, CityInfoPayload.CODEC,
                (p, ctx) -> ctx.enqueueWork(() -> ClientAccess.onCityInfo(p)));
        r.playToClient(ArmyInfoPayload.TYPE, ArmyInfoPayload.CODEC,
                (p, ctx) -> ctx.enqueueWork(() -> ClientAccess.onArmyInfo(p)));

        r.playToServer(CityActionPayload.TYPE, CityActionPayload.CODEC,
                (p, ctx) -> ctx.enqueueWork(() -> {
                    if (asServer(ctx) instanceof ServerPlayer sp) CityActions.handle(sp, p);
                }));
        r.playToServer(ArmyOrderPayload.TYPE, ArmyOrderPayload.CODEC,
                (p, ctx) -> ctx.enqueueWork(() -> {
                    if (asServer(ctx) instanceof ServerPlayer sp) ArmyCommands.handle(sp, p);
                }));
    }

    private static Player asServer(IPayloadContext ctx) {
        return ctx.player();
    }
}
