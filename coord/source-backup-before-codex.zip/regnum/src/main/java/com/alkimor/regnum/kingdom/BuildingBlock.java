package com.alkimor.regnum.kingdom;

import com.alkimor.regnum.core.Text;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

/** Блок городской постройки (казарма, рынок, башня). Работает только на своей территории. */
public class BuildingBlock extends Block {
    private final BuildingType type;

    public BuildingBlock(BuildingType type, Properties props) {
        super(props);
        this.type = type;
    }

    public BuildingType type() {
        return type;
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        if (ctx.getLevel() instanceof ServerLevel sl && ctx.getPlayer() != null) {
            City c = KingdomData.get(sl.getServer()).at(ctx.getClickedPos());
            if (c == null || !c.owner.equals(ctx.getPlayer().getUUID()) || sl.dimension() != Level.OVERWORLD) {
                Text.bad(ctx.getPlayer(), type.title + " ставится только на территории вашего города.");
                return null;
            }
            int limit = 1 + c.level;
            if (c.count(type) >= limit) {
                Text.bad(ctx.getPlayer(), "Предел построек «" + type.title + "» для города " + c.level + " уровня: " + limit + ". Развивайте город.");
                return null;
            }
        }
        return super.getStateForPlacement(ctx);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level instanceof ServerLevel sl && placer instanceof ServerPlayer player) {
            KingdomData data = KingdomData.get(sl.getServer());
            City c = data.at(pos);
            if (c != null) {
                c.buildings.put(pos.asLong(), type);
                data.setDirty();
                player.sendSystemMessage(Text.of("Построено: " + type.title + " в «" + c.name + "». ", ChatFormatting.GREEN)
                        .append(Text.of(type.effect, ChatFormatting.GRAY)));
            }
        }
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel sl) {
            KingdomData data = KingdomData.get(sl.getServer());
            for (City c : data.all()) {
                if (c.buildings.remove(pos.asLong()) != null) {
                    data.setDirty();
                    break;
                }
            }
        }
        super.onRemove(state, level, pos, newState, moved);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (player instanceof ServerPlayer sp) {
            City c = KingdomData.get(sp.server).at(pos);
            if (c != null && c.buildings.containsKey(pos.asLong())) {
                if (c.owner.equals(sp.getUUID())) {
                    CityActions.openScreen(sp, c.hall);
                } else {
                    Text.info(sp, type.title + " города «" + c.name + "».");
                }
            } else {
                Text.info(sp, "Эта постройка не принадлежит ни одному городу.");
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
