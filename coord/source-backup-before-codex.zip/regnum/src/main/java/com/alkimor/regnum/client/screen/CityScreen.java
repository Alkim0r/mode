package com.alkimor.regnum.client.screen;

import com.alkimor.regnum.core.network.CityActionPayload;
import com.alkimor.regnum.core.network.CityInfoPayload;
import com.alkimor.regnum.kingdom.SoldierType;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** Экран ратуши: казна, армия, постройки, найм и развитие. */
public class CityScreen extends RegnumScreen {
    private final CityInfoPayload info;
    private EditBox nameBox;

    public CityScreen(CityInfoPayload info) {
        super(Component.literal("«" + info.name() + "» — город " + info.level() + " уровня"), 340, 230);
        this.info = info;
    }

    private void send(int action, int arg, String text) {
        PacketDistributor.sendToServer(new CityActionPayload(info.hall(), action, arg, text));
    }

    @Override
    protected void init() {
        super.init();
        int bx = left + 180, bw = 150, y = top + 28;
        addRenderableWidget(Button.builder(Component.literal("Внести изумруды"), b -> send(CityActionPayload.DEPOSIT, 0, ""))
                .bounds(bx, y, 73, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Взять 16"), b -> send(CityActionPayload.WITHDRAW, 0, ""))
                .bounds(bx + 77, y, 73, 18).build());
        y += 24;
        for (SoldierType t : new SoldierType[]{SoldierType.SWORDSMAN, SoldierType.ARCHER, SoldierType.KNIGHT}) {
            Button btn = Button.builder(Component.literal("Нанять: " + t.title + " (" + t.cost + ")"),
                    b -> send(CityActionPayload.RECRUIT, t.ordinal(), "")).bounds(bx, y, bw, 18).build();
            btn.active = info.barracks() > 0 && info.level() >= t.minCityLevel && info.treasury() >= t.cost && info.army() < info.armyCap();
            addRenderableWidget(btn);
            y += 20;
        }
        addRenderableWidget(Button.builder(Component.literal("Отряд для найма: " + info.recruitSquad()),
                b -> send(CityActionPayload.SET_SQUAD, info.recruitSquad() % 4 + 1, "")).bounds(bx, y, bw, 18).build());
        y += 24;
        Button up = Button.builder(Component.literal(info.level() >= 5 ? "Город развит полностью"
                        : "Развить (" + info.upgradeCost() + " изумр., " + info.upgradeGlory() + " славы)"),
                b -> send(CityActionPayload.UPGRADE, 0, "")).bounds(bx, y, bw, 18).build();
        up.active = info.level() < 5 && info.treasury() >= info.upgradeCost() && info.glory() >= info.upgradeGlory();
        addRenderableWidget(up);
        y += 26;
        nameBox = new EditBox(font, bx, y, 96, 18, Component.literal("Имя города"));
        nameBox.setMaxLength(32);
        nameBox.setValue(info.name());
        addRenderableWidget(nameBox);
        addRenderableWidget(Button.builder(Component.literal("Переим."), b -> send(CityActionPayload.RENAME, 0, nameBox.getValue()))
                .bounds(bx + 100, y, 50, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Закрыть"), b -> onClose())
                .bounds(left + panelW / 2 - 40, top + panelH - 24, 80, 18).build());
    }

    @Override
    protected void drawContents(GuiGraphics g, int mouseX, int mouseY) {
        int x = left + 10, y = top + 28;
        int gold = 0xFFE8C872, text = 0xFFDDD5C0, dim = 0xFF9A9080, red = 0xFFE05A4A;
        g.drawString(font, "Правитель: " + info.ruler(), x, y, gold); y += 14;
        g.drawString(font, "Казна: " + info.treasury() + " изумр.", x, y, text); y += 11;
        g.drawString(font, "  в день: +" + info.dailyIncome() + " / −" + info.dailyUpkeep(), x, y, dim); y += 13;
        g.drawString(font, "Слава: " + info.glory(), x, y, text); y += 11;
        g.drawString(font, "Жители: " + info.population() + "   Территория: " + info.radius(), x, y, text); y += 15;
        g.drawString(font, "Армия: " + info.army() + " / " + info.armyCap(), x, y, gold); y += 11;
        g.drawString(font, "  мечники " + info.swordsmen() + ", лучники " + info.archers() + ", рыцари " + info.knights(), x, y, dim); y += 15;
        g.drawString(font, "Постройки:", x, y, gold); y += 11;
        g.drawString(font, "  казармы " + info.barracks() + ", рынки " + info.markets() + ", башни " + info.towers(), x, y, dim); y += 15;
        if (info.raidActive()) {
            g.drawString(font, "⚔ ИДЁТ НАБЕГ!", x, y, red);
        } else {
            g.drawString(font, "Набег разбойников: через " + info.daysToRaid() + " дн.", x, y, info.daysToRaid() <= 1 ? red : text);
        }
        y += 15;
        if (info.barracks() == 0) g.drawString(font, "Постройте казарму для найма войск", x, y, dim);
    }
}
