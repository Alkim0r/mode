package com.alkimor.regnum.survival;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

/** Данные выжившего, прикреплённые к игроку: опыт навыков и честь. */
public class SurvivorData {
    public static final Codec<SurvivorData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.unboundedMap(Codec.STRING, Codec.INT).optionalFieldOf("xp", Map.of()).forGetter(SurvivorData::exportXp),
            Codec.INT.optionalFieldOf("honor", 0).forGetter(SurvivorData::honor)
    ).apply(i, SurvivorData::fromSaved));

    private final EnumMap<Skill, Integer> xp = new EnumMap<>(Skill.class);
    private int honor;

    public SurvivorData() {}

    private static SurvivorData fromSaved(Map<String, Integer> xp, Integer honor) {
        SurvivorData d = new SurvivorData();
        xp.forEach((k, v) -> {
            Skill s = Skill.byKey(k);
            if (s != null) d.xp.put(s, v);
        });
        d.honor = honor;
        return d;
    }

    private Map<String, Integer> exportXp() {
        Map<String, Integer> m = new HashMap<>();
        xp.forEach((k, v) -> m.put(k.key, v));
        return m;
    }

    public int xp(Skill s) {
        return xp.getOrDefault(s, 0);
    }

    public int level(Skill s) {
        return Skill.levelFor(xp(s));
    }

    public void addXp(Skill s, int amount) {
        xp.put(s, Math.max(0, xp(s) + amount));
    }

    public int honor() {
        return honor;
    }

    public void addHonor(int delta) {
        honor = Math.max(-100, Math.min(100, honor + delta));
    }

    public static String honorTitle(int honor) {
        if (honor >= 60) return "Легенда";
        if (honor >= 30) return "Благородный";
        if (honor >= 10) return "Честный";
        if (honor > -10) return "Неизвестный";
        if (honor > -30) return "Сомнительный";
        if (honor > -60) return "Разбойник";
        return "Изгой";
    }
}
