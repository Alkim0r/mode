package com.alkimor.regnum.client.render;

import com.alkimor.regnum.dungeon.CryptLordEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

/** Морграт: увеличенный костяной воин в короне. */
public class CryptLordRenderer extends HumanoidMobRenderer<CryptLordEntity, HumanoidModel<CryptLordEntity>> {
    private static final ResourceLocation TEXTURE = ResourceLocation.withDefaultNamespace("textures/entity/skeleton/wither_skeleton.png");

    public CryptLordRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.WITHER_SKELETON)), 0.9f);
        addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.WITHER_SKELETON_INNER_ARMOR)),
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.WITHER_SKELETON_OUTER_ARMOR)),
                ctx.getModelManager()));
    }

    @Override
    protected void scale(CryptLordEntity entity, PoseStack pose, float partialTick) {
        pose.scale(1.3f, 1.3f, 1.3f);
    }

    @Override
    public ResourceLocation getTextureLocation(CryptLordEntity entity) {
        return TEXTURE;
    }
}
