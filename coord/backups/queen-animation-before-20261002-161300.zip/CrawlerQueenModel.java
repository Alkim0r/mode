package com.alkimor.regnum.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import com.alkimor.regnum.mine.CrawlerQueenEntity;

/** Фазы и боевые позы привязаны к синхронизированным состояниям Королевы. */
public final class CrawlerQueenModel extends EntityModel<CrawlerQueenEntity> {
    public static final net.minecraft.client.model.geom.ModelLayerLocation LAYER =
            CrawlerQueenGeometry.LAYER;

    private final ModelPart root;
    private final java.util.List<ModelPart> poseParts;
    private final ModelPart head;
    private final ModelPart abdomen;
    private final ModelPart fissures;
    private final ModelPart core;
    private final ModelPart flapLeft;
    private final ModelPart flapRight;
    private final ModelPart mandibleLeft;
    private final ModelPart mandibleRight;
    private final ModelPart sacLeft;
    private final ModelPart sacRight;
    private final java.util.List<ModelPart> decor;
    private final ModelPart[] upperLegs = new ModelPart[8];
    private final ModelPart[] lowerLegs = new ModelPart[8];

    public CrawlerQueenModel(ModelPart root) {
        super(RenderType::entityCutoutNoCull);
        this.root = root;
        poseParts = root.getAllParts().toList();
        head = root.getChild("head");
        abdomen = root.getChild("abdomen");
        fissures = abdomen.getChild("phase_two_fissures");
        core = abdomen.getChild("phase_three_core");
        flapLeft = abdomen.getChild("shell_flap_l");
        flapRight = abdomen.getChild("shell_flap_r");
        mandibleLeft = head.getChild("mandible_l");
        mandibleRight = head.getChild("mandible_r");
        sacLeft = head.getChild("acid_sac_l");
        sacRight = head.getChild("acid_sac_r");
        decor = CrawlerQueenGeometry.decor(root);
        int i = 0;
        for (String side : new String[]{"l", "r"}) {
            for (String row : new String[]{"front", "mid_front", "mid_back", "rear"}) {
                String name = "leg_" + row + "_" + side;
                upperLegs[i] = root.getChild(name);
                lowerLegs[i] = upperLegs[i].getChild(name + "_shin");
                i++;
            }
        }
    }

    @Override
    public void setupAnim(CrawlerQueenEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        for (ModelPart part : poseParts) part.resetPose();
        head.yRot += Mth.clamp(netHeadYaw, -40.0F, 40.0F) * Mth.DEG_TO_RAD;
        head.xRot += Mth.clamp(headPitch, -25.0F, 30.0F) * Mth.DEG_TO_RAD;
        boolean detailed = !com.alkimor.regnum.core.RegnumClientConfig.decorHidden();
        for (ModelPart part : decor) part.visible = detailed;

        float ratio = entity.getHealth() / Math.max(1.0F, entity.getMaxHealth());
        int phaseId = Math.max(entity.getVisualPhase(), ratio <= 0.33F ? 3 : ratio <= 0.66F ? 2 : 1);
        boolean phaseTwo = phaseId >= 2;
        boolean phaseThree = phaseId >= 3;
        fissures.visible = phaseTwo;
        core.visible = phaseThree;

        float stride = Mth.clamp(limbSwingAmount, 0.0F, 1.0F);
        float idle = Mth.sin(ageInTicks * 0.075F);
        float partialTick = Mth.clamp(ageInTicks - entity.tickCount, 0.0F, 1.0F);
        float attack = Mth.sin(Mth.clamp(entity.getAttackAnim(partialTick), 0.0F, 1.0F) * Mth.PI);
        boolean lunging = entity.getDeltaMovement().y > 0.12;
        float spread = phaseThree ? 0.78F : phaseTwo ? 0.38F : 0.0F;
        flapLeft.zRot += spread + idle * 0.015F;
        flapRight.zRot -= spread + idle * 0.015F;
        abdomen.xRot += idle * 0.022F;
        head.y += idle * 0.1F;
        head.xRot += -0.24F * attack + (lunging ? -0.25F : idle * 0.018F);
        float gape = idle * 0.02F + attack * 0.42F;
        mandibleLeft.yRot += gape;
        mandibleRight.yRot -= gape;
        mandibleLeft.xRot -= attack * 0.18F;
        mandibleRight.xRot -= attack * 0.18F;
        if (entity.hurtTime > 0) head.zRot += Mth.sin(entity.hurtTime * 0.65F) * 0.06F;

        for (int i = 0; i < upperLegs.length; i++) {
            float phase = limbSwing * 0.62F + ((i + (i / 4)) % 2 == 0 ? 0.0F : Mth.PI);
            float gait = Mth.cos(phase) * 0.20F * stride;
            float lift = Math.max(0.0F, Mth.sin(phase)) * 0.12F * stride;
            float sideSign = i < 4 ? -1.0F : 1.0F;
            upperLegs[i].yRot += gait;
            upperLegs[i].zRot -= sideSign * (lift + (i % 4 == 0 ? 0.18F * attack : 0.0F));
            lowerLegs[i].zRot += sideSign * lift * 0.4F;
        }
        if (lunging) {
            head.xRot -= 0.2F;
            for (int i = 0; i < upperLegs.length; i++) upperLegs[i].zRot -= (i < 4 ? -1.0F : 1.0F) * 0.12F;
        }
        animateAction(entity.getVisualAction(), entity.getVisualActionTicks() + partialTick,
                entity.getVisualActionDuration(), ageInTicks);
    }

    private void animateAction(int action, float elapsed, int duration, float age) {
        if (action == CrawlerQueenEntity.ACT_IDLE || duration <= 0) return;
        float progress = Mth.clamp(elapsed / duration, 0.0F, 1.0F);
        float envelope = Mth.sin(progress * Mth.PI);
        switch (action) {
            case CrawlerQueenEntity.ACT_ACID -> {
                // The server releases the cloud at tick 22, then allows eight ticks of recoil.
                float windup = Mth.clamp(elapsed / 22.0F, 0.0F, 1.0F);
                float recoil = elapsed < 22.0F ? 0.0F : 1.0F - Mth.clamp((elapsed - 22.0F) / 8.0F, 0.0F, 1.0F);
                head.xRot += elapsed < 22.0F ? -windup * 0.4F : recoil * 0.22F;
                float gape = elapsed < 22.0F ? windup * 0.4F : recoil * 0.6F;
                mandibleLeft.yRot += gape;
                mandibleRight.yRot -= gape;
                float swell = 1.0F + (elapsed < 22.0F ? windup : recoil) * 0.4F;
                sacLeft.xScale = sacLeft.yScale = sacRight.xScale = sacRight.yScale = swell;
            }
            case CrawlerQueenEntity.ACT_CHARGE -> {
                head.xRot += progress * 0.32F;
                abdomen.xRot -= progress * 0.16F;
                for (int i = 0; i < 8; i++) {
                    float side = i < 4 ? -1.0F : 1.0F;
                    upperLegs[i].zRot -= side * progress * (i % 4 < 2 ? 0.2F : 0.1F);
                    upperLegs[i].yRot += side * progress * (i % 4 < 2 ? -0.16F : 0.14F);
                }
            }
            case CrawlerQueenEntity.ACT_STUNNED -> {
                float hold = Mth.clamp((duration - elapsed) / 8.0F, 0.0F, 1.0F);
                head.xRot += hold * 0.55F;
                head.zRot += hold * Mth.sin(age * 0.55F) * 0.07F;
                mandibleLeft.yRot += hold * 0.12F;
                mandibleRight.yRot -= hold * 0.12F;
                abdomen.xRot += hold * 0.08F;
            }
            case CrawlerQueenEntity.ACT_BROOD, CrawlerQueenEntity.ACT_CAVEIN, CrawlerQueenEntity.ACT_DARKNESS -> {
                float raise = envelope * (action == CrawlerQueenEntity.ACT_BROOD ? 0.45F : 0.3F);
                abdomen.xRot -= envelope * 0.15F;
                head.xRot -= envelope * 0.2F;
                flapLeft.zRot += envelope * 0.12F;
                flapRight.zRot -= envelope * 0.12F;
                for (int i = 0; i < 8; i++) if (i % 4 >= 2) {
                    float side = i < 4 ? -1.0F : 1.0F;
                    upperLegs[i].zRot -= side * raise;
                    lowerLegs[i].zRot += side * raise * 0.3F;
                }
                if (action == CrawlerQueenEntity.ACT_DARKNESS) {
                    head.zRot += envelope * Mth.sin(age * 0.4F) * 0.08F;
                    mandibleLeft.yRot += envelope * 0.35F;
                    mandibleRight.yRot -= envelope * 0.35F;
                }
            }
            default -> { }
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer vertices, int light, int overlay,
                               int color) {
        root.render(pose, vertices, light, overlay, color);
    }
}
