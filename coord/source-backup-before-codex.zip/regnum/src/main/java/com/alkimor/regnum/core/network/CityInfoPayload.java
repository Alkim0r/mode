package com.alkimor.regnum.core.network;

import com.alkimor.regnum.Regnum;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Сервер → клиент: состояние города для экрана ратуши. */
public record CityInfoPayload(BlockPos hall, String name, String ruler, int level, int radius, int population,
                              int treasury, int glory, int army, int armyCap,
                              int barracks, int markets, int towers,
                              int daysToRaid, boolean raidActive, int recruitSquad,
                              int upgradeCost, int upgradeGlory, int dailyIncome, int dailyUpkeep,
                              int swordsmen, int archers, int knights) implements CustomPacketPayload {
    public static final Type<CityInfoPayload> TYPE = new Type<>(Regnum.id("city_info"));
    public static final StreamCodec<FriendlyByteBuf, CityInfoPayload> CODEC = StreamCodec.ofMember(CityInfoPayload::write, CityInfoPayload::read);

    private void write(FriendlyByteBuf b) {
        b.writeBlockPos(hall);
        b.writeUtf(name, 64);
        b.writeUtf(ruler, 64);
        b.writeVarIntArray(new int[]{level, radius, population, treasury, glory, army, armyCap, barracks, markets, towers,
                daysToRaid, raidActive ? 1 : 0, recruitSquad, upgradeCost, upgradeGlory, dailyIncome, dailyUpkeep,
                swordsmen, archers, knights});
    }

    private static CityInfoPayload read(FriendlyByteBuf b) {
        BlockPos hall = b.readBlockPos();
        String name = b.readUtf(64);
        String ruler = b.readUtf(64);
        int[] v = b.readVarIntArray();
        return new CityInfoPayload(hall, name, ruler, v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9],
                v[10], v[11] == 1, v[12], v[13], v[14], v[15], v[16], v[17], v[18], v[19]);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
