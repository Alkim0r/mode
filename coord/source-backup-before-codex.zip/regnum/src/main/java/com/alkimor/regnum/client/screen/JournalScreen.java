package com.alkimor.regnum.client.screen;

import com.alkimor.regnum.survival.Skill;
import com.alkimor.regnum.survival.Skills;
import com.alkimor.regnum.survival.SurvivalModule;
import com.alkimor.regnum.survival.SurvivorData;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;

/** Дневник выжившего: навыки (как в Project Zomboid), честь и травмы. */
public class JournalScreen extends RegnumScreen {
    public JournalScreen() {
        super(Component.literal("Дневник выжившего"), 300, 230);
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.literal("Закрыть"), b -> onClose())
                .bounds(left + panelW / 2 - 40, top + panelH - 24, 80, 18).build());
    }

    @Override
    protected void drawContents(GuiGraphics g, int mouseX, int mouseY) {
        int x = left + 10, y = top + 28;
        int text = 0xFFDDD5C0, dim = 0xFF9A9080, gold = 0xFFE8C872;
        for (Skill s : Skill.values()) {
            int xp = Skills.clientXp.length > s.ordinal() ? Skills.clientXp[s.ordinal()] : 0;
            int lvl = Skill.levelFor(xp);
            g.drawString(font, s.title, x, y + 1, text);
            // 10 делений, как в PZ
            for (int i = 0; i < Skill.MAX_LEVEL; i++) {
                int sx = x + 100 + i * 12;
                int color = i < lvl ? 0xFFE8C872 : 0xFF3A3024;
                g.fill(sx, y, sx + 10, y + 9, color);
            }
            if (lvl < Skill.MAX_LEVEL) {
                int from = Skill.XP_TABLE[lvl], to = Skill.XP_TABLE[lvl + 1];
                float part = (xp - from) / (float) (to - from);
                int sx = x + 100 + lvl * 12;
                g.fill(sx, y + 7, sx + Math.round(10 * part), y + 9, 0xFF8FD16A);
            }
            g.drawString(font, String.valueOf(lvl), x + 228, y + 1, gold);
            if (mouseX >= x && mouseX <= x + 240 && mouseY >= y && mouseY <= y + 10) {
                g.renderTooltip(font, Component.literal(s.bonus), mouseX, mouseY);
            }
            y += 14;
        }
        y += 6;
        int honor = Skills.clientHonor;
        g.drawString(font, "Честь: " + honor + " — «" + SurvivorData.honorTitle(honor) + "»", x, y, gold);
        y += 16;
        g.drawString(font, "Состояние:", x, y, gold);
        y += 12;
        Player p = minecraft != null ? minecraft.player : null;
        boolean any = false;
        if (p != null) {
            if (p.hasEffect(SurvivalModule.BLEEDING)) { g.drawString(font, "• Кровотечение — нужен бинт", x, y, 0xFFE05A4A); y += 11; any = true; }
            if (p.hasEffect(SurvivalModule.FRACTURE)) { g.drawString(font, "• Перелом — нужна шина", x, y, 0xFFE0B04A); y += 11; any = true; }
            if (p.hasEffect(SurvivalModule.INFECTION)) { g.drawString(font, "• Инфекция — нужен целебный отвар", x, y, 0xFF9BC24A); y += 11; any = true; }
        }
        if (!any) g.drawString(font, "• Здоров", x, y, dim);
    }
}
