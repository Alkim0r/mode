package com.alkimor.regnum.kingdom;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

public final class KingdomEvents {
    private KingdomEvents() {}

    /** Стрелы своих не ранят союзников. */
    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        if (!(event.getRayTraceResult() instanceof EntityHitResult hit)) return;
        Entity shooter = event.getProjectile().getOwner();
        Entity victim = hit.getEntity();
        if (shooter instanceof SoldierEntity s && s.isAlliedTo(victim)) {
            event.setCanceled(true);
        } else if (shooter instanceof Player p && victim instanceof SoldierEntity s && s.isOwnedBy(p)) {
            event.setCanceled(true);
        }
    }

    /** Король не ранит своих солдат случайно (с Shift — может, например, чтобы наказать). */
    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (event.getEntity() instanceof SoldierEntity s && event.getSource().getEntity() instanceof Player p
                && s.isOwnedBy(p) && !p.isShiftKeyDown()) {
            event.setCanceled(true);
        }
    }

    /** Вербовка жителей жезлом: перехватываем до открытия торговли. */
    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getItemStack().getItem() instanceof CommanderBatonItem)) return;
        if (!(event.getTarget() instanceof Villager v)) return;
        if (event.getEntity() instanceof ServerPlayer sp) {
            ArmyCommands.recruitVillager(sp, v);
        }
        event.setCancellationResult(InteractionResult.SUCCESS);
        event.setCanceled(true);
    }
}
