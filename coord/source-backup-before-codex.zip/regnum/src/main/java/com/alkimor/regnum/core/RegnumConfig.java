package com.alkimor.regnum.core;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Общий конфиг: config/regnum-common.toml */
public final class RegnumConfig {
    private RegnumConfig() {}

    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    // --- Выживание ---
    public static final ModConfigSpec.BooleanValue SURVIVAL_ENABLED;
    public static final ModConfigSpec.DoubleValue SKILL_XP_MULTIPLIER;
    public static final ModConfigSpec.BooleanValue INJURIES_ENABLED;
    public static final ModConfigSpec.DoubleValue BLEEDING_CHANCE_MULTIPLIER;

    // --- Королевство ---
    public static final ModConfigSpec.BooleanValue KINGDOM_ENABLED;
    public static final ModConfigSpec.IntValue MAX_CITIES_PER_PLAYER;
    public static final ModConfigSpec.BooleanValue RAIDS_ENABLED;
    public static final ModConfigSpec.IntValue RAID_INTERVAL_DAYS;
    public static final ModConfigSpec.BooleanValue UPKEEP_ENABLED;
    public static final ModConfigSpec.IntValue TAX_PER_VILLAGER;

    // --- Странники ---
    public static final ModConfigSpec.BooleanValue WANDERERS_ENABLED;
    public static final ModConfigSpec.DoubleValue WANDERER_SPAWN_CHANCE;

    static {
        B.comment("Модуль «Выживание»: навыки, травмы, медицина").push("survival");
        SURVIVAL_ENABLED = B.comment("Включить прокачку навыков").define("enabled", true);
        SKILL_XP_MULTIPLIER = B.comment("Множитель опыта навыков").defineInRange("skillXpMultiplier", 1.0, 0.1, 20.0);
        INJURIES_ENABLED = B.comment("Кровотечения, переломы, инфекции").define("injuries", true);
        BLEEDING_CHANCE_MULTIPLIER = B.comment("Множитель шанса кровотечения").defineInRange("bleedingChanceMultiplier", 1.0, 0.0, 5.0);
        B.pop();

        B.comment("Модуль «Королевство»: города, армия, набеги").push("kingdom");
        KINGDOM_ENABLED = B.define("enabled", true);
        MAX_CITIES_PER_PLAYER = B.comment("Сколько городов может основать один игрок").defineInRange("maxCitiesPerPlayer", 5, 1, 64);
        RAIDS_ENABLED = B.comment("Набеги разбойников на города").define("raids", true);
        RAID_INTERVAL_DAYS = B.comment("Раз в сколько игровых дней приходит набег").defineInRange("raidIntervalDays", 3, 1, 100);
        UPKEEP_ENABLED = B.comment("Ежедневное жалованье армии из казны").define("upkeep", true);
        TAX_PER_VILLAGER = B.comment("Налог с одного жителя в день (изумруды)").defineInRange("taxPerVillager", 1, 0, 64);
        B.pop();

        B.comment("Модуль «Странники»: NPC с характером").push("wanderers");
        WANDERERS_ENABLED = B.define("enabled", true);
        WANDERER_SPAWN_CHANCE = B.comment("Шанс появления странника рядом с игроком раз в минуту").defineInRange("spawnChance", 0.12, 0.0, 1.0);
        B.pop();
    }

    public static final ModConfigSpec SPEC = B.build();
}
