package com.alkimor.regnum.kingdom;

import com.alkimor.regnum.core.RegnumModule;
import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;

import static com.alkimor.regnum.core.ModRegistries.*;

/** Модуль «Королевство»: города, постройки, армия, приказы, набеги. */
public class KingdomModule implements RegnumModule {

    // --- Сущности
    public static final DeferredHolder<EntityType<?>, EntityType<SoldierEntity>> SOLDIER = ENTITIES.register("soldier",
            () -> EntityType.Builder.of(SoldierEntity::new, MobCategory.MISC).sized(0.6f, 1.95f).clientTrackingRange(10).build("soldier"));
    public static final DeferredHolder<EntityType<?>, EntityType<BanditEntity>> BANDIT = ENTITIES.register("bandit",
            () -> EntityType.Builder.of(BanditEntity::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(8).build("bandit"));

    // --- Блоки
    private static BlockBehaviour.Properties buildingProps(MapColor color) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(4.0f, 12.0f).sound(SoundType.WOOD);
    }

    public static final DeferredBlock<TownHallBlock> TOWN_HALL = BLOCKS.register("town_hall",
            () -> new TownHallBlock(buildingProps(MapColor.GOLD).strength(6.0f, 1200.0f)));
    public static final DeferredBlock<BuildingBlock> BARRACKS = BLOCKS.register("barracks",
            () -> new BuildingBlock(BuildingType.BARRACKS, buildingProps(MapColor.COLOR_RED)));
    public static final DeferredBlock<BuildingBlock> MARKET = BLOCKS.register("market",
            () -> new BuildingBlock(BuildingType.MARKET, buildingProps(MapColor.EMERALD)));
    public static final DeferredBlock<BuildingBlock> WATCHTOWER = BLOCKS.register("watchtower",
            () -> new BuildingBlock(BuildingType.WATCHTOWER, buildingProps(MapColor.STONE)));

    public static final DeferredItem<BlockItem> TOWN_HALL_ITEM = ITEMS.registerSimpleBlockItem("town_hall", TOWN_HALL, new Item.Properties().rarity(Rarity.UNCOMMON));
    public static final DeferredItem<BlockItem> BARRACKS_ITEM = ITEMS.registerSimpleBlockItem("barracks", BARRACKS);
    public static final DeferredItem<BlockItem> MARKET_ITEM = ITEMS.registerSimpleBlockItem("market", MARKET);
    public static final DeferredItem<BlockItem> WATCHTOWER_ITEM = ITEMS.registerSimpleBlockItem("watchtower", WATCHTOWER);

    // --- Предметы
    public static final DeferredItem<CommanderBatonItem> COMMANDER_BATON = ITEMS.register("commander_baton",
            () -> new CommanderBatonItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<DeferredSpawnEggItem> BANDIT_EGG = ITEMS.register("bandit_spawn_egg",
            () -> new DeferredSpawnEggItem(BANDIT, 0x4A3B2A, 0x8B1A1A, new Item.Properties()));

    // --- Компоненты жезла
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> BATON_SQUAD = COMPONENTS.registerComponentType("baton_squad",
            b -> b.persistent(Codec.intRange(0, 4)).networkSynchronized(ByteBufCodecs.VAR_INT));
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> BATON_FORMATION = COMPONENTS.registerComponentType("baton_formation",
            b -> b.persistent(Codec.intRange(0, 3)).networkSynchronized(ByteBufCodecs.VAR_INT));

    @Override
    public String id() {
        return "kingdom";
    }

    @Override
    public String title() {
        return "Королевство";
    }

    @Override
    public void init(IEventBus modBus) {
        modBus.addListener(KingdomModule::attributes);
        NeoForge.EVENT_BUS.register(KingdomEvents.class);
        NeoForge.EVENT_BUS.addListener(KingdomManager::onServerTick);
    }

    private static void attributes(EntityAttributeCreationEvent event) {
        event.put(SOLDIER.get(), SoldierEntity.createAttributes().build());
        event.put(BANDIT.get(), BanditEntity.createAttributes().build());
    }
}
