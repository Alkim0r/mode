package com.alkimor.regnum.kingdom;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Город игрока. Хранится в {@link KingdomData}. */
public class City {
    public static final int MAX_LEVEL = 5;

    public final UUID id;
    public UUID owner;
    public String name;
    public BlockPos hall;
    public int level = 1;
    public int treasury = 0;
    public int glory = 0;
    public int population = 0;
    public int recruitSquad = 1;
    public long lastEconomyDay = -1;
    public long nextRaidDay = -1;

    /** Постройки: позиция блока → тип. */
    public final Map<Long, BuildingType> buildings = new HashMap<>();
    /** Солдаты города: UUID → тип (ordinal). */
    public final Map<UUID, Integer> soldiers = new HashMap<>();

    // --- Набег
    public boolean raidActive = false;
    public int raidWave = 0;
    public int raidWavesTotal = 0;
    public int raidDelay = 0;
    public int raidTimer = 0;
    public int raidStolen = 0;
    public int raidWaveSize = 0;
    public final Set<UUID> raiders = new HashSet<>();

    public City(UUID id, UUID owner, String name, BlockPos hall) {
        this.id = id;
        this.owner = owner;
        this.name = name;
        this.hall = hall;
    }

    public int radius() {
        return 24 + 8 * level;
    }

    public int count(BuildingType t) {
        int n = 0;
        for (BuildingType b : buildings.values()) if (b == t) n++;
        return n;
    }

    public int armyCap(int leadershipLevel) {
        return 4 + count(BuildingType.BARRACKS) * 5 + level * 2 + leadershipLevel;
    }

    public int countSoldiers(SoldierType t) {
        int n = 0;
        for (int v : soldiers.values()) if (v == t.ordinal()) n++;
        return n;
    }

    public int dailyUpkeep() {
        int u = 0;
        for (int v : soldiers.values()) u += SoldierType.byId(v).upkeep;
        return u;
    }

    public int dailyIncome(int taxPerVillager) {
        return population * taxPerVillager + count(BuildingType.MARKET) * 3 + level;
    }

    public int upgradeCost() {
        return 30 * level;
    }

    public int upgradeGlory() {
        return 20 * (level - 1);
    }

    public boolean contains(BlockPos p) {
        double dx = p.getX() - hall.getX(), dz = p.getZ() - hall.getZ();
        return dx * dx + dz * dz <= (double) radius() * radius();
    }

    // ------------------------------------------------------------------ NBT

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putUUID("id", id);
        t.putUUID("owner", owner);
        t.putString("name", name);
        t.putLong("hall", hall.asLong());
        t.putInt("level", level);
        t.putInt("treasury", treasury);
        t.putInt("glory", glory);
        t.putInt("population", population);
        t.putInt("recruitSquad", recruitSquad);
        t.putLong("lastEconomyDay", lastEconomyDay);
        t.putLong("nextRaidDay", nextRaidDay);

        ListTag b = new ListTag();
        buildings.forEach((pos, type) -> {
            CompoundTag e = new CompoundTag();
            e.putLong("pos", pos);
            e.putString("type", type.name());
            b.add(e);
        });
        t.put("buildings", b);

        ListTag s = new ListTag();
        soldiers.forEach((uuid, type) -> {
            CompoundTag e = new CompoundTag();
            e.putUUID("id", uuid);
            e.putInt("type", type);
            s.add(e);
        });
        t.put("soldiers", s);

        t.putBoolean("raidActive", raidActive);
        t.putInt("raidWave", raidWave);
        t.putInt("raidWavesTotal", raidWavesTotal);
        t.putInt("raidStolen", raidStolen);
        ListTag r = new ListTag();
        for (UUID u : raiders) {
            CompoundTag e = new CompoundTag();
            e.putUUID("id", u);
            r.add(e);
        }
        t.put("raiders", r);
        return t;
    }

    public static City load(CompoundTag t) {
        City c = new City(t.getUUID("id"), t.getUUID("owner"), t.getString("name"), BlockPos.of(t.getLong("hall")));
        c.level = Math.max(1, t.getInt("level"));
        c.treasury = t.getInt("treasury");
        c.glory = t.getInt("glory");
        c.population = t.getInt("population");
        c.recruitSquad = Math.max(1, t.getInt("recruitSquad"));
        c.lastEconomyDay = t.getLong("lastEconomyDay");
        c.nextRaidDay = t.getLong("nextRaidDay");
        for (Tag e : t.getList("buildings", Tag.TAG_COMPOUND)) {
            CompoundTag ct = (CompoundTag) e;
            try {
                c.buildings.put(ct.getLong("pos"), BuildingType.valueOf(ct.getString("type")));
            } catch (IllegalArgumentException ignored) {
            }
        }
        for (Tag e : t.getList("soldiers", Tag.TAG_COMPOUND)) {
            CompoundTag ct = (CompoundTag) e;
            c.soldiers.put(ct.getUUID("id"), ct.getInt("type"));
        }
        c.raidActive = t.getBoolean("raidActive");
        c.raidWave = t.getInt("raidWave");
        c.raidWavesTotal = t.getInt("raidWavesTotal");
        c.raidStolen = t.getInt("raidStolen");
        for (Tag e : t.getList("raiders", Tag.TAG_COMPOUND)) {
            c.raiders.add(((CompoundTag) e).getUUID("id"));
        }
        return c;
    }
}
