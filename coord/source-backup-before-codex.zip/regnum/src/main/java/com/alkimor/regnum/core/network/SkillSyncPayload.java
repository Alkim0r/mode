package com.alkimor.regnum.core.network;

import com.alkimor.regnum.Regnum;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Сервер → клиент: опыт навыков, честь, активные травмы (для дневника и длительности лечения). */
public record SkillSyncPayload(int[] xp, int honor, boolean openJournal) implements CustomPacketPayload {
    public static final Type<SkillSyncPayload> TYPE = new Type<>(Regnum.id("skill_sync"));
    public static final StreamCodec<FriendlyByteBuf, SkillSyncPayload> CODEC = StreamCodec.ofMember(SkillSyncPayload::write, SkillSyncPayload::read);

    private void write(FriendlyByteBuf buf) {
        buf.writeVarIntArray(xp);
        buf.writeVarInt(honor);
        buf.writeBoolean(openJournal);
    }

    private static SkillSyncPayload read(FriendlyByteBuf buf) {
        return new SkillSyncPayload(buf.readVarIntArray(), buf.readVarInt(), buf.readBoolean());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
