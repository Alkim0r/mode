package com.alkimor.regnum.survival;

import net.minecraft.ChatFormatting;

/**
 * Навыки в стиле Project Zomboid: растут только от действий.
 * Уровни 0..10, порог опыта — {@link #XP_TABLE}.
 */
public enum Skill {
    MELEE("melee", "Ближний бой", ChatFormatting.RED, "+4% урона в ближнем бою за уровень"),
    ARCHERY("archery", "Стрельба", ChatFormatting.GREEN, "+4% урона снарядами за уровень"),
    MEDICINE("medicine", "Медицина", ChatFormatting.LIGHT_PURPLE, "Быстрее и сильнее лечение, выше шанс вылечить инфекцию"),
    FORAGING("foraging", "Собирательство", ChatFormatting.DARK_GREEN, "Выше шанс найти травы и полезные мелочи"),
    FITNESS("fitness", "Выносливость", ChatFormatting.GOLD, "+1 сердце за каждые 3 уровня"),
    SMITHING("smithing", "Кузнечное дело", ChatFormatting.GRAY, "Выше шанс успешной закалки, доступ к высоким ступеням"),
    LEADERSHIP("leadership", "Командование", ChatFormatting.BLUE, "+1 к лимиту армии за уровень");

    public static final int MAX_LEVEL = 10;
    /** XP_TABLE[n] — суммарный опыт, нужный для уровня n. */
    public static final int[] XP_TABLE = {0, 60, 180, 380, 680, 1100, 1650, 2350, 3200, 4250, 5500};

    public final String key;
    public final String title;
    public final ChatFormatting color;
    public final String bonus;

    Skill(String key, String title, ChatFormatting color, String bonus) {
        this.key = key;
        this.title = title;
        this.color = color;
        this.bonus = bonus;
    }

    public static int levelFor(int xp) {
        int lvl = 0;
        for (int i = 1; i <= MAX_LEVEL; i++) {
            if (xp >= XP_TABLE[i]) lvl = i;
        }
        return lvl;
    }

    public static Skill byKey(String key) {
        for (Skill s : values()) if (s.key.equals(key)) return s;
        return null;
    }
}
