package com.alkimor.regnum.kingdom.ai;

import com.alkimor.regnum.kingdom.SoldierEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/** Стрельба лучников: держат дистанцию 8–16 блоков и бьют залпами. */
public class SoldierRangedGoal extends Goal {
    private final SoldierEntity soldier;
    private int cooldown;
    private int seeTime;

    public SoldierRangedGoal(SoldierEntity soldier) {
        this.soldier = soldier;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = soldier.getTarget();
        return soldier.isArcher() && t != null && t.isAlive();
    }

    @Override
    public void stop() {
        seeTime = 0;
        soldier.getNavigation().stop();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        LivingEntity t = soldier.getTarget();
        if (t == null) return;
        double d2 = soldier.distanceToSqr(t);
        boolean see = soldier.getSensing().hasLineOfSight(t);
        seeTime = see ? seeTime + 1 : 0;

        if (d2 > 16 * 16 || !see) {
            soldier.getNavigation().moveTo(t, 1.1);
        } else if (d2 < 6 * 6) {
            // отступить на шаг от врага
            double dx = soldier.getX() - t.getX(), dz = soldier.getZ() - t.getZ();
            double len = Math.max(0.01, Math.sqrt(dx * dx + dz * dz));
            soldier.getNavigation().moveTo(soldier.getX() + dx / len * 4, soldier.getY(), soldier.getZ() + dz / len * 4, 1.2);
        } else {
            soldier.getNavigation().stop();
        }
        soldier.getLookControl().setLookAt(t, 30f, 30f);

        if (--cooldown <= 0 && see && seeTime > 5 && d2 <= 18 * 18) {
            soldier.performRangedAttack(t, 1.0f);
            soldier.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
            cooldown = 30 + soldier.getRandom().nextInt(10);
        }
    }
}
