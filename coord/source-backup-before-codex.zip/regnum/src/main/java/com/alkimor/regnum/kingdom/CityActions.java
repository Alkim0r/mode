package com.alkimor.regnum.kingdom;

import com.alkimor.regnum.core.InvUtil;
import com.alkimor.regnum.core.Text;
import com.alkimor.regnum.core.network.CityActionPayload;
import com.alkimor.regnum.core.network.CityInfoPayload;
import com.alkimor.regnum.survival.Skill;
import com.alkimor.regnum.survival.Skills;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Серверная логика экрана ратуши. */
public final class CityActions {
    private CityActions() {}

    public static String rulerTitle(KingdomData data, UUID owner) {
        List<City> cs = data.ownedBy(owner);
        int total = 0;
        for (City c : cs) total += c.level;
        if (cs.size() >= 5 && total >= 15) return "Император";
        if (cs.size() >= 3 && total >= 8) return "Король";
        if (cs.size() >= 2 || total >= 3) return "Князь";
        return "Вождь";
    }

    public static void openScreen(ServerPlayer sp, BlockPos hall) {
        KingdomData data = KingdomData.get(sp.server);
        City c = data.byHall(hall);
        if (c == null) {
            Text.info(sp, "Эта ратуша не основала город (возможно, её поставили не вы).");
            return;
        }
        if (!c.owner.equals(sp.getUUID())) {
            Text.info(sp, "Город «" + c.name + "», уровень " + c.level + ". Правитель — не вы.");
            return;
        }
        long day = sp.serverLevel().getDayTime() / 24000L;
        int lead = Skills.level(sp, Skill.LEADERSHIP);
        PacketDistributor.sendToPlayer(sp, new CityInfoPayload(c.hall, c.name, rulerTitle(data, c.owner), c.level, c.radius(), c.population,
                c.treasury, c.glory, c.soldiers.size(), c.armyCap(lead),
                c.count(BuildingType.BARRACKS), c.count(BuildingType.MARKET), c.count(BuildingType.WATCHTOWER),
                (int) Math.max(0, c.nextRaidDay - day), c.raidActive, c.recruitSquad,
                c.upgradeCost(), c.upgradeGlory(), c.dailyIncome(com.alkimor.regnum.core.RegnumConfig.TAX_PER_VILLAGER.get()), c.dailyUpkeep(),
                c.countSoldiers(SoldierType.SWORDSMAN) + c.countSoldiers(SoldierType.MILITIA), c.countSoldiers(SoldierType.ARCHER), c.countSoldiers(SoldierType.KNIGHT)));
    }

    public static void handle(ServerPlayer sp, CityActionPayload p) {
        KingdomData data = KingdomData.get(sp.server);
        City c = data.byHall(p.hall());
        if (c == null || !c.owner.equals(sp.getUUID())) return;
        if (!sp.blockPosition().closerThan(c.hall, c.radius() + 16)) {
            Text.bad(sp, "Вы слишком далеко от города.");
            return;
        }
        switch (p.action()) {
            case CityActionPayload.DEPOSIT -> {
                int n = InvUtil.count(sp, Items.EMERALD);
                if (n == 0) {
                    Text.bad(sp, "В инвентаре нет изумрудов.");
                } else {
                    InvUtil.take(sp, Items.EMERALD, n);
                    c.treasury += n;
                    Text.good(sp, "В казну внесено " + n + " изумр.");
                }
            }
            case CityActionPayload.WITHDRAW -> {
                int n = Math.min(16, c.treasury);
                if (n > 0) {
                    c.treasury -= n;
                    InvUtil.give(sp, new ItemStack(Items.EMERALD, n));
                    Text.good(sp, "Из казны взято " + n + " изумр.");
                }
            }
            case CityActionPayload.RECRUIT -> recruit(sp, c, SoldierType.byId(p.arg()));
            case CityActionPayload.UPGRADE -> upgrade(sp, c);
            case CityActionPayload.RENAME -> {
                String name = p.text().trim();
                if (name.length() >= 2 && name.length() <= 32) {
                    c.name = name;
                    Text.good(sp, "Город переименован в «" + name + "».");
                }
            }
            case CityActionPayload.SET_SQUAD -> c.recruitSquad = Math.max(1, Math.min(4, p.arg()));
            default -> {}
        }
        data.setDirty();
        openScreen(sp, c.hall);
    }

    private static void recruit(ServerPlayer sp, City c, SoldierType type) {
        if (type == SoldierType.MILITIA) {
            Text.info(sp, "Ополченцев вербуют среди жителей: возьмите жезл командира и нажмите ПКМ по жителю (4 изумруда).");
            return;
        }
        if (c.count(BuildingType.BARRACKS) == 0) {
            Text.bad(sp, "Для найма нужна казарма.");
            return;
        }
        if (c.level < type.minCityLevel) {
            Text.bad(sp, type.title + " доступен с " + type.minCityLevel + " уровня города.");
            return;
        }
        int cap = c.armyCap(Skills.level(sp, Skill.LEADERSHIP));
        if (c.soldiers.size() >= cap) {
            Text.bad(sp, "Армия города достигла предела (" + cap + "). Стройте казармы и развивайте Командование.");
            return;
        }
        if (c.treasury < type.cost) {
            Text.bad(sp, "В казне недостаточно изумрудов: нужно " + type.cost + ".");
            return;
        }
        ServerLevel level = sp.serverLevel();
        BlockPos at = c.hall;
        for (Map.Entry<Long, BuildingType> e : c.buildings.entrySet()) {
            if (e.getValue() == BuildingType.BARRACKS) {
                at = BlockPos.of(e.getKey());
                break;
            }
        }
        SoldierEntity s = KingdomModule.SOLDIER.get().create(level);
        if (s == null) return;
        BlockPos spawn = findStandPos(level, at);
        s.moveTo(spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5, sp.getYRot() + 180f, 0f);
        s.finalizeSpawn(level, level.getCurrentDifficultyAt(spawn), MobSpawnType.MOB_SUMMONED, null);
        s.setup(type, sp.getUUID(), c.id, c.recruitSquad);
        s.command(Order.HOLD, Vec3.atBottomCenterOf(spawn), sp.getYRot(), Formation.LINE, 0, 1, null);
        level.addFreshEntity(s);
        c.treasury -= type.cost;
        c.soldiers.put(s.getUUID(), type.ordinal());
        level.playSound(null, spawn, SoundEvents.ARMOR_EQUIP_IRON.value(), SoundSource.NEUTRAL, 1f, 1f);
        Text.good(sp, "Нанят: " + type.title + " (отряд " + c.recruitSquad + "). Жалованье: " + type.upkeep + " изумр./день.");
        Skills.addXp(sp, Skill.LEADERSHIP, 6);
    }

    private static BlockPos findStandPos(ServerLevel level, BlockPos near) {
        for (int i = 0; i < 16; i++) {
            BlockPos p = near.offset(level.random.nextInt(5) - 2, 0, level.random.nextInt(5) - 2);
            for (int dy = 2; dy >= -2; dy--) {
                BlockPos q = p.above(dy);
                if (level.getBlockState(q.below()).isSolid() && level.getBlockState(q).isAir() && level.getBlockState(q.above()).isAir()) return q;
            }
        }
        return near.above();
    }

    private static void upgrade(ServerPlayer sp, City c) {
        if (c.level >= City.MAX_LEVEL) {
            Text.info(sp, "Город уже достиг наивысшего уровня.");
            return;
        }
        if (c.treasury < c.upgradeCost() || c.glory < c.upgradeGlory()) {
            Text.bad(sp, "Для развития нужно " + c.upgradeCost() + " изумр. в казне и " + c.upgradeGlory() + " славы.");
            return;
        }
        c.treasury -= c.upgradeCost();
        c.level++;
        sp.serverLevel().playSound(null, c.hall, SoundEvents.PLAYER_LEVELUP, SoundSource.BLOCKS, 1f, 0.8f);
        Text.gold(sp, "🏰 «" + c.name + "» вырос до " + c.level + " уровня! Территория: " + c.radius() + " блоков.");
        Skills.addXp(sp, Skill.LEADERSHIP, 50 * c.level);
    }
}
